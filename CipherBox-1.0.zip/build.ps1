#requires -version 5
# CipherBox build script.
# Requires only the .NET Framework compiler that ships with Windows (csc.exe).
# Usage: powershell -ExecutionPolicy Bypass -File .\build.ps1

param(
    [string]$OutDir = (Join-Path $PSScriptRoot "dist")
)

$ErrorActionPreference = "Stop"

$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) {
    $csc = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe"
}
if (-not (Test-Path $csc)) {
    throw "csc.exe not found. Please install .NET Framework 4.x."
}

$src = Join-Path $PSScriptRoot "src"
$core = @(
    (Join-Path $src "Core\Crypto.cs"),
    (Join-Path $src "Core\PasswordTools.cs")
)
$app = @(
    (Join-Path $src "App\Theme.cs"),
    (Join-Path $src "App\Controls.cs"),
    (Join-Path $src "App\Page.cs"),
    (Join-Path $src "App\MainForm.cs"),
    (Join-Path $src "App\PageText.cs"),
    (Join-Path $src "App\PageEncode.cs"),
    (Join-Path $src "App\PageHash.cs"),
    (Join-Path $src "App\PagePasswordTools.cs"),
    (Join-Path $src "App\Program.cs"),
    (Join-Path $src "App\AssemblyInfo.cs")
)

if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
$out = Join-Path $OutDir "CipherBox.exe"

& $csc /nologo /codepage:65001 /target:winexe /optimize+ `
    /win32icon:"$PSScriptRoot\assets\app.ico" `
    /win32manifest:"$PSScriptRoot\src\App\app.manifest" `
    /out:"$out" `
    /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll `
    $core $app

if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE." }
Write-Host "Build OK: $out" -ForegroundColor Green
Write-Host ("Size: {0:N0} bytes" -f (Get-Item $out).Length)
