﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CipherBox 密码工具箱")]
[assembly: AssemblyDescription("本地文本与文件加解密、哈希、编码、RSA 与口令强度检测工具")]
[assembly: AssemblyProduct("CipherBox")]
[assembly: AssemblyCompany("CipherBox")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
