using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace CipherBox.App
{
    public enum BtnKind
    {
        Primary,
        Ghost,
        Subtle,
        Danger,
        Link
    }

    /// <summary>扁平圆角按钮，带悬停/按下反馈。</summary>
    public class Btn : Control
    {
        public BtnKind Kind = BtnKind.Primary;
        private bool hover;
        private bool down;

        public Btn()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Bg;
            Font = Th.Font(9.5f);
            Cursor = Cursors.Hand;
            Height = Th.S(38);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            hover = false;
            down = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            down = true;
            Invalidate();
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            down = false;
            Invalidate();
            base.OnMouseUp(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            Cursor = Enabled ? Cursors.Hand : Cursors.Default;
            Invalidate();
            base.OnEnabledChanged(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            g.FillRectangle(new SolidBrush(BackColor), ClientRectangle);
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            int radius = Th.S(8);

            Color text = Th.Text;
            if (Kind == BtnKind.Primary)
            {
                Color a = down ? Th.AccentDeep : (hover ? Th.Accent : Th.AccentDeep);
                Color b = down ? Th.AccentDeep : (hover ? Th.Violet : Th.Accent);
                Th.FillRoundGradient(g, r, radius, a, b, 0f);
                text = Color.White;
            }
            else if (Kind == BtnKind.Ghost)
            {
                if (hover) Th.FillRound(g, r, radius, Th.CardHover);
                Th.DrawRound(g, r, radius, hover ? Th.Accent : Th.Border, 1f);
                text = hover ? Th.Text : Th.Muted;
            }
            else if (Kind == BtnKind.Subtle)
            {
                Th.FillRound(g, r, radius, hover ? Th.CardHover : Th.CardAlt);
                Th.DrawRound(g, r, radius, Th.BorderSoft, 1f);
                text = Th.Text;
            }
            else if (Kind == BtnKind.Danger)
            {
                Th.FillRound(g, r, radius, hover ? Th.Hex("#42222A") : Th.Hex("#33202A"));
                Th.DrawRound(g, r, radius, Th.Hex("#5C2E39"), 1f);
                text = Th.Danger;
            }
            else
            {
                text = hover ? Th.Accent : Th.Hex("#7FB0FF");
            }

            if (!Enabled)
            {
                text = Th.Dim;
            }

            TextRenderer.DrawText(g, Text, Font, r, text, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis);
        }
    }

    /// <summary>带圆角边框的输入框，支持占位符、多行与密码显隐。</summary>
    public class Field : Panel
    {
        public readonly TextBox Box;
        private readonly Label hint;
        private readonly string hintText;
        private bool focused;
        private bool reveal;
        private Btn eye;

        public bool IsPassword;
        /// <summary>输入区填充色，用于只读输出框等变体。</summary>
        public Color Fill = Th.Input;

        public string Value
        {
            get { return Box.Text; }
            set { Box.Text = value; }
        }

        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
        private static extern int SetWindowTheme(IntPtr hWnd, string subApp, string subId);

        public Field(string placeholder, bool multiline)
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Input;
            hintText = placeholder ?? "";

            Box = new TextBox();
            Box.BorderStyle = BorderStyle.None;
            Box.BackColor = Th.Input;
            Box.ForeColor = Th.Text;
            Box.Font = Th.Font(10f);
            Box.Multiline = multiline;
            if (multiline)
            {
                Box.ScrollBars = ScrollBars.Vertical;
                Box.AcceptsReturn = true;
                Box.Font = Th.Mono(9.5f);
            }
            Box.GotFocus += delegate { focused = true; Invalidate(); };
            Box.LostFocus += delegate { focused = false; Invalidate(); };
            Box.HandleCreated += delegate
            {
                if (Box.Multiline) SetWindowTheme(Box.Handle, "DarkMode_Explorer", null);
            };
            Box.TextChanged += delegate { SyncHint(); };
            Box.KeyDown += delegate(object s, KeyEventArgs e) { OnKeyDown(e); };
            Controls.Add(Box);

            hint = new Label();
            hint.AutoSize = false;
            hint.BackColor = Box.BackColor;
            hint.ForeColor = Th.Dim;
            hint.Font = Box.Font;
            hint.Text = hintText;
            hint.Cursor = Cursors.IBeam;
            hint.Click += delegate { Box.Focus(); };
            Controls.Add(hint);
            hint.BringToFront();
        }

        public void SetTone(Color fill, Color text)
        {
            Fill = fill;
            Box.BackColor = fill;
            hint.BackColor = fill;
            if (text != Color.Empty) Box.ForeColor = text;
            Invalidate();
        }

        public void EnablePasswordToggle()
        {
            IsPassword = true;
            Box.UseSystemPasswordChar = true;
            eye = new Btn();
            eye.Kind = BtnKind.Link;
            eye.Text = "显示";
            eye.Font = Th.Font(8.5f);
            eye.Height = Th.S(24);
            eye.Width = Th.S(44);
            eye.BackColor = Th.Input;
            eye.Click += delegate
            {
                reveal = !reveal;
                Box.UseSystemPasswordChar = !reveal;
                eye.Text = reveal ? "隐藏" : "显示";
            };
            Controls.Add(eye);
            eye.BringToFront();
            OnResize(EventArgs.Empty);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            int padX = Th.S(12);
            int padY = Th.S(9);
            int right = Width - padX;
            if (eye != null)
            {
                eye.Location = new Point(Width - padX - eye.Width, (Height - eye.Height) / 2);
                right -= eye.Width + Th.S(4);
            }
            Box.SetBounds(padX, padY, Math.Max(Th.S(10), right - padX), Math.Max(Th.S(16), Height - padY * 2));
            hint.SetBounds(padX + Th.S(1), padY + Th.S(1), Math.Max(Th.S(10), right - padX - Th.S(2)), Math.Max(Th.S(16), Height - padY * 2));
            SyncHint();
        }

        private void SyncHint()
        {
            bool show = Box.Text.Length == 0 && hintText.Length > 0;
            if (hint.Visible != show) hint.Visible = show;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            Th.FillRound(g, r, Th.S(8), focused ? Th.InputFocus : Fill);
            Th.DrawRound(g, r, Th.S(8), focused ? Th.Accent : Th.Border, 1f);
        }
    }

    /// <summary>深色下拉选择器。</summary>
    public class Combo : Control
    {
        public string[] Items = new string[0];
        private int selected;
        private bool hover;

        public event EventHandler Changed;

        public int SelectedIndex
        {
            get { return selected; }
            set
            {
                int v = value;
                if (v < 0) v = 0;
                if (v >= Items.Length) v = Math.Max(0, Items.Length - 1);
                if (v != selected)
                {
                    selected = v;
                    Invalidate();
                    if (Changed != null) Changed(this, EventArgs.Empty);
                }
            }
        }

        public string SelectedText
        {
            get { return Items.Length == 0 ? "" : Items[Math.Min(selected, Items.Length - 1)]; }
        }

        public Combo()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Bg;
            Height = Th.S(40);
            Cursor = Cursors.Hand;
            Font = Th.Font(9.5f);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            hover = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Open();
        }

        private void Open()
        {
            if (Items.Length == 0) return;
            DropListForm f = new DropListForm(Items, selected, Width, Font);
            Point p = PointToScreen(new Point(0, Height + Th.S(4)));
            if (p.Y + f.Height > Screen.FromControl(this).WorkingArea.Bottom)
            {
                p = PointToScreen(new Point(0, -f.Height - Th.S(4)));
            }
            f.Location = p;
            f.Show();
            f.Closed += delegate
            {
                if (f.Picked >= 0) SelectedIndex = f.Picked;
            };
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            Th.FillRound(g, r, Th.S(8), hover ? Th.InputFocus : Th.Input);
            Th.DrawRound(g, r, Th.S(8), hover ? Th.Accent : Th.Border, 1f);
            Rectangle textRect = new Rectangle(Th.S(12), 0, Width - Th.S(36), Height);
            TextRenderer.DrawText(g, SelectedText, Font, textRect, Th.Text, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis);
            using (Pen pen = new Pen(Th.Muted, Th.F(1.4f)))
            {
                int cx = Width - Th.S(18);
                int cy = Height / 2;
                g.DrawLines(pen, new PointF[]
                {
                    new PointF(cx - Th.S(4), cy - Th.S(2)),
                    new PointF(cx, cy + Th.S(3)),
                    new PointF(cx + Th.S(4), cy - Th.S(2))
                });
            }
        }
    }

    internal class DropListForm : Form
    {
        private readonly ListBox list;
        public int Picked = -1;

        public DropListForm(string[] items, int index, int width, Font font)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            BackColor = Th.Border;
            Padding = new Padding(1);
            DoubleBuffered = true;
            int itemH = Th.S(32);
            int h = Math.Min(itemH * items.Length + 2, Th.S(300));
            Size = new Size(width, h);

            list = new ListBox();
            list.BorderStyle = BorderStyle.None;
            list.DrawMode = DrawMode.OwnerDrawFixed;
            list.ItemHeight = itemH;
            list.BackColor = Th.Card;
            list.ForeColor = Th.Text;
            list.Font = font;
            list.IntegralHeight = false;
            list.Items.AddRange(items);
            list.SelectedIndex = Math.Min(index, items.Length - 1);
            list.DrawItem += delegate(object s, DrawItemEventArgs e)
            {
                if (e.Index < 0) return;
                bool sel = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
                Graphics g = e.Graphics;
                g.FillRectangle(new SolidBrush(sel ? Th.AccentSoft : Th.Card), e.Bounds);
                Color c = sel ? Th.Text : Th.Muted;
                Rectangle r = new Rectangle(e.Bounds.X + Th.S(10), e.Bounds.Y, e.Bounds.Width - Th.S(16), e.Bounds.Height);
                TextRenderer.DrawText(g, (string)list.Items[e.Index], list.Font, r, c, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
            list.Click += delegate
            {
                if (list.SelectedIndex >= 0) Picked = list.SelectedIndex;
                Close();
            };
            list.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    Picked = list.SelectedIndex;
                    Close();
                }
                else if (e.KeyCode == Keys.Escape) Close();
            };
            Controls.Add(list);
            Deactivate += delegate { Close(); };
            using (GraphicsPath p = Th.Round(new Rectangle(0, 0, Width, Height), Th.S(8)))
            {
                Region = new Region(p);
            }
        }
    }

    /// <summary>分段选择器。</summary>
    public class Seg : Control
    {
        public string[] Items = new string[0];
        private int selected;

        public event EventHandler Changed;

        public int SelectedIndex
        {
            get { return selected; }
            set
            {
                if (value < 0 || value >= Items.Length) return;
                if (selected != value)
                {
                    selected = value;
                    Invalidate();
                    if (Changed != null) Changed(this, EventArgs.Empty);
                }
            }
        }

        public Seg()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Bg;
            Height = Th.S(38);
            Cursor = Cursors.Hand;
            Font = Th.Font(9.5f);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (Items.Length == 0) return;
            int cell = Width / Items.Length;
            int idx = Math.Min(Items.Length - 1, Math.Max(0, e.X / Math.Max(1, cell)));
            SelectedIndex = idx;
            base.OnMouseDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            Th.FillRound(g, r, Th.S(8), Th.Hex("#0E1622"));
            Th.DrawRound(g, r, Th.S(8), Th.Border, 1f);
            if (Items.Length == 0) return;
            int cell = Width / Items.Length;
            for (int i = 0; i < Items.Length; i++)
            {
                Rectangle cellRect = new Rectangle(i * cell + Th.S(3), Th.S(3), cell - Th.S(6), Height - Th.S(6));
                bool on = i == selected;
                if (on)
                {
                    Th.FillRoundGradient(g, cellRect, Th.S(6), Th.AccentDeep, Th.Accent, 0f);
                }
                TextRenderer.DrawText(g, Items[i], Font, cellRect, on ? Color.White : Th.Muted,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
        }
    }

    /// <summary>开关。</summary>
    public class Toggle : Control
    {
        private bool isChecked;

        public bool Checked
        {
            get { return isChecked; }
            set { isChecked = value; Invalidate(); }
        }

        public Toggle()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Bg;
            Size = new Size(Th.S(38), Th.S(20));
            Cursor = Cursors.Hand;
        }

        protected override void OnClick(EventArgs e)
        {
            isChecked = !isChecked;
            Invalidate();
            base.OnClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle track = new Rectangle(0, 0, Width - 1, Height - 1);
            Th.FillRound(g, track, Height / 2, isChecked ? Th.Accent : Th.Hex("#263242"));
            int d = Height - Th.S(6);
            int x = isChecked ? Width - d - Th.S(3) : Th.S(3);
            using (SolidBrush kb = new SolidBrush(Color.White))
            {
                g.FillEllipse(kb, x, Th.S(3), d, d);
            }
        }
    }

    /// <summary>侧边导航项。</summary>
    public class NavItem : Control
    {
        public Glyph Icon = Glyph.Lock;
        private bool active;
        private bool hover;

        public bool Active
        {
            get { return active; }
            set { active = value; Invalidate(); }
        }

        public NavItem()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Sidebar;
            Height = Th.S(42);
            Cursor = Cursors.Hand;
            Font = Th.Font(9.5f);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            hover = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle r = new Rectangle(Th.S(10), Th.S(3), Width - Th.S(20), Height - Th.S(6));
            if (active) Th.FillRound(g, r, Th.S(8), Th.AccentSoft);
            else if (hover) Th.FillRound(g, r, Th.S(8), Th.CardAlt);
            Color fg = active ? Th.Text : (hover ? Th.Text : Th.Muted);
            if (active)
            {
                using (SolidBrush ab = new SolidBrush(Th.Accent))
                {
                    g.FillRectangle(ab, r.X + Th.S(2), r.Y + Th.S(10), Th.S(3), r.Height - Th.S(20));
                }
            }
            Rectangle iconRect = new Rectangle(r.X + Th.S(14), r.Y + (r.Height - Th.S(16)) / 2, Th.S(16), Th.S(16));
            Icons.Draw(g, Icon, iconRect, active ? Th.Accent : fg, Th.F(1.5f));
            Rectangle textRect = new Rectangle(iconRect.Right + Th.S(12), r.Y, r.Width - Th.S(50), r.Height);
            TextRenderer.DrawText(g, Text, Font, textRect, fg, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }

    /// <summary>圆角卡片容器。</summary>
    public class Card : Panel
    {
        public Color Fill = Th.Card;
        public Color Stroke = Th.BorderSoft;
        public int Radius = 12;
        public bool DrawStroke = true;

        public Card()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Bg;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            Th.FillRound(g, r, Radius, Fill);
            if (DrawStroke) Th.DrawRound(g, r, Radius, Stroke, 1f);
            base.OnPaint(e);
        }
    }

    /// <summary>进度条。</summary>
    public class Progress : Control
    {
        private double value;

        public double Value
        {
            get { return value; }
            set { this.value = Math.Max(0, Math.Min(1, value)); Invalidate(); }
        }

        public Color ColorA = Th.AccentDeep;
        public Color ColorB = Th.Teal;

        public Progress()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Card;
            Height = Th.S(8);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            Rectangle r = new Rectangle(0, 0, Width, Height);
            Th.FillRound(g, r, Height / 2, Th.Hex("#0A1018"));
            int w = (int)(Width * value);
            if (w > 2)
            {
                Rectangle fill = new Rectangle(0, 0, w, Height);
                Th.FillRoundGradient(g, fill, Height / 2, ColorA, ColorB, 0f);
            }
        }
    }
}
