using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CipherBox.App
{
    /// <summary>无边框主窗口：自定义标题栏 + 侧边导航 + 页面容器。</summary>
    public class MainForm : Form
    {
        public const int DesignWidth = 1180;
        public const int DesignHeight = 760;
        private const int SidebarWidth = 208;
        private const int TitleHeight = 52;
        private const int StatusHeight = 30;

        public static MainForm Instance;

        private Panel host;
        private Panel sidebar;
        private Panel titleBar;
        private Panel statusPanel;
        private string statusText = "就绪";
        private readonly List<NavItem> navs = new List<NavItem>();
        private readonly List<Page> pages = new List<Page>();
        private int current = -1;
        private string hintText = "所有运算均在本地完成 · 不上传任何数据";
        private Color hintColor = Th.Dim;
        private const string DefaultHint = "所有运算均在本地完成 · 不上传任何数据";
        private Timer toastTimer;


        public MainForm()
        {
            Instance = this;
            Text = "CipherBox 密码工具箱";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Th.Bg;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(Th.S(DesignWidth), Th.S(DesignHeight));
            DoubleBuffered = true;
            Font = Th.Font(9f);
            KeyPreview = true;

            BuildTitleBar();
            BuildSidebar();
            BuildHost();
            BuildStatus();
            BuildToast();

            Controls.Add(host);
            Controls.Add(sidebar);
            Controls.Add(titleBar);
            Controls.Add(statusPanel);

            LoadPages();
            Select(0);
        }

        private void BuildTitleBar()
        {
            titleBar = new Panel();
            titleBar.SetBounds(0, 0, ClientSize.Width, Th.S(TitleHeight));
            titleBar.BackColor = Th.Sidebar;
            titleBar.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Th.Setup(g);
                g.FillRectangle(new SolidBrush(Th.Sidebar), titleBar.ClientRectangle);
                Rectangle logo = new Rectangle(Th.S(20), Th.S(12), Th.S(28), Th.S(28));
                Th.FillRoundGradient(g, logo, Th.S(8), Th.AccentDeep, Th.Violet, 45f);
                Rectangle icon = new Rectangle(logo.X + Th.S(7), logo.Y + Th.S(7), Th.S(14), Th.S(14));
                Icons.Draw(g, Glyph.Lock, icon, Color.White, Th.F(1.6f));
                TextRenderer.DrawText(g, "CipherBox", Th.Bold(11f), new Rectangle(Th.S(58), Th.S(7), Th.S(200), Th.S(22)), Th.Text, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "密码工具箱", Th.Font(9f), new Rectangle(Th.S(58), Th.S(28), Th.S(200), Th.S(18)), Th.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                using (Pen p = new Pen(Th.BorderSoft))
                {
                    g.DrawLine(p, 0, titleBar.Height - 1, titleBar.Width, titleBar.Height - 1);
                }
            };

            WinBtn min = new WinBtn(WinBtnKind.Minimize);
            min.SetBounds(ClientSize.Width - Th.S(96), 0, Th.S(44), Th.S(TitleHeight));
            min.Click += delegate { WindowState = FormWindowState.Minimized; };
            WinBtn close = new WinBtn(WinBtnKind.Close);
            close.SetBounds(ClientSize.Width - Th.S(48), 0, Th.S(44), Th.S(TitleHeight));
            close.Click += delegate { Close(); };
            titleBar.Controls.Add(min);
            titleBar.Controls.Add(close);

            Point dragOffset = Point.Empty;
            bool dragging = false;
            titleBar.MouseDown += delegate(object s, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left)
                {
                    dragging = true;
                    dragOffset = e.Location;
                }
            };
            titleBar.MouseMove += delegate(object s, MouseEventArgs e)
            {
                if (!dragging) return;
                Point screen = titleBar.PointToScreen(e.Location);
                Location = new Point(screen.X - dragOffset.X, screen.Y - dragOffset.Y);
            };
            titleBar.MouseUp += delegate { dragging = false; };
        }

        private void BuildSidebar()
        {
            sidebar = new Panel();
            sidebar.SetBounds(0, Th.S(TitleHeight), Th.S(SidebarWidth), ClientSize.Height - Th.S(TitleHeight));
            sidebar.BackColor = Th.Sidebar;
            sidebar.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Th.Setup(g);
                g.FillRectangle(new SolidBrush(Th.Sidebar), sidebar.ClientRectangle);
                TextRenderer.DrawText(g, "功 能", Th.Font(8f), new Rectangle(Th.S(22), Th.S(18), Th.S(120), Th.S(16)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                using (Pen p = new Pen(Th.BorderSoft))
                {
                    g.DrawLine(p, Th.S(14), sidebar.Height - Th.S(62), sidebar.Width - Th.S(14), sidebar.Height - Th.S(62));
                }
                TextRenderer.DrawText(g, "本地运行 · 数据不出本机", Th.Font(8f), new Rectangle(Th.S(20), sidebar.Height - Th.S(50), Th.S(180), Th.S(16)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "v1.0.0  ·  .NET Framework 4.8", Th.Font(7.5f), new Rectangle(Th.S(20), sidebar.Height - Th.S(32), Th.S(190), Th.S(16)), Th.Hex("#414B5C"), TextFormatFlags.Left | TextFormatFlags.NoPadding);
            };
        }

        private void BuildHost()
        {
            host = new Panel();
            host.SetBounds(Th.S(SidebarWidth), Th.S(TitleHeight), ClientSize.Width - Th.S(SidebarWidth), ClientSize.Height - Th.S(TitleHeight) - Th.S(StatusHeight));
            host.BackColor = Th.Bg;
        }

        private void BuildStatus()
        {
            statusPanel = new Panel();
            statusPanel.SetBounds(Th.S(SidebarWidth), ClientSize.Height - Th.S(StatusHeight), ClientSize.Width - Th.S(SidebarWidth), Th.S(StatusHeight));
            statusPanel.BackColor = Th.Sidebar;
            statusPanel.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                using (Pen p = new Pen(Th.BorderSoft))
                {
                    g.DrawLine(p, 0, 0, statusPanel.Width, 0);
                }
                TextRenderer.DrawText(g, statusText, Th.Font(8.5f), new Rectangle(Th.S(18), 0, Th.S(560), statusPanel.Height), Th.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, hintText, Th.Font(8.5f), new Rectangle(statusPanel.Width - Th.S(420), 0, Th.S(400), statusPanel.Height), hintColor, TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
        }

        private void BuildToast()
        {
            toastTimer = new Timer();
            toastTimer.Interval = 2000;
            toastTimer.Tick += delegate
            {
                toastTimer.Stop();
                hintText = DefaultHint;
                hintColor = Th.Dim;
                statusPanel.Invalidate();
            };
        }

        private void LoadPages()
        {
            Page[] all =
            {
                new PageText(),
                new PageEncode(),
                new PageHash(),
                new PagePasswordTools()
            };
            Glyph[] glyphs = { Glyph.Lock, Glyph.Code, Glyph.Hash, Glyph.Shield };
            string[] titles = { "文本加解密", "编码转换", "哈希与摘要", "密码中心" };

            for (int i = 0; i < all.Length; i++)
            {
                Page p = all[i];
                p.SetBounds(0, 0, host.Width, host.Height);
                p.Visible = false;
                host.Controls.Add(p);
                pages.Add(p);

                NavItem nav = new NavItem();
                nav.Text = titles[i];
                nav.Icon = glyphs[i];
                nav.SetBounds(Th.S(10), Th.S(96) + i * Th.S(46), Th.S(188), Th.S(42));
                int idx = i;
                nav.Click += delegate { Select(idx); };
                sidebar.Controls.Add(nav);
                navs.Add(nav);
            }
        }

        public void Select(int index)
        {
            if (index < 0 || index >= pages.Count || index == current) return;
            current = index;
            for (int i = 0; i < pages.Count; i++)
            {
                pages[i].Visible = i == index;
                navs[i].Active = i == index;
            }
            pages[index].BuildIfNeeded();
        }

        public void ShowToast(string message)
        {
            ShowToast(message, Th.Text);
        }

        public void ShowToast(string message, Color color)
        {
            hintText = message;
            hintColor = color;
            statusPanel.Invalidate();
            toastTimer.Stop();
            toastTimer.Start();
        }

        public void SetStatus(string text)
        {
            statusText = text;
            if (statusPanel != null) statusPanel.Invalidate();
        }
    }

    public enum WinBtnKind
    {
        Minimize,
        Close
    }

    /// <summary>标题栏窗口按钮。</summary>
    public class WinBtn : Control
    {
        private readonly WinBtnKind kind;
        private bool hover;

        public WinBtn(WinBtnKind kind)
        {
            this.kind = kind;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Th.Sidebar;
            Cursor = Cursors.Hand;
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            hover = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, ClientRectangle);
            if (hover)
            {
                Color c = kind == WinBtnKind.Close ? Th.Hex("#C42B1C") : Th.CardHover;
                Th.FillRound(g, new Rectangle(Th.S(4), Th.S(4), Width - Th.S(8), Height - Th.S(8)), Th.S(6), c);
            }
            using (Pen p = new Pen(hover && kind == WinBtnKind.Close ? Color.White : Th.Muted, Th.F(1.4f)))
            {
                int cx = Width / 2;
                int cy = Height / 2;
                if (kind == WinBtnKind.Minimize)
                {
                    g.DrawLine(p, cx - Th.S(6), cy, cx + Th.S(6), cy);
                }
                else
                {
                    g.DrawLine(p, cx - Th.S(5), cy - Th.S(5), cx + Th.S(5), cy + Th.S(5));
                    g.DrawLine(p, cx + Th.S(5), cy - Th.S(5), cx - Th.S(5), cy + Th.S(5));
                }
            }
        }
    }
}
