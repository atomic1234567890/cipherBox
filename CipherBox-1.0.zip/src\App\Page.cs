using System;
using System.Drawing;
using System.Windows.Forms;

namespace CipherBox.App
{
    /// <summary>页面基类：统一页头绘制与常用控件工厂。</summary>
    public abstract class Page : Panel
    {
        public string Title;
        public string Desc;
        private bool built;
        protected const int PadX = 32;

        protected Page(string title, string desc)
        {
            Title = title;
            Desc = desc;
            BackColor = Th.Bg;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        }

        public void BuildIfNeeded()
        {
            if (built) return;
            built = true;
            Build();
        }

        protected abstract void Build();

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            Th.Setup(g);
            using (SolidBrush b = new SolidBrush(Th.Bg)) g.FillRectangle(b, ClientRectangle);
            using (SolidBrush ab = new SolidBrush(Th.Accent))
            {
                g.FillRectangle(ab, Th.S(PadX - 12), Th.S(30), Th.S(3), Th.S(18));
            }
            TextRenderer.DrawText(g, Title, Th.Bold(14f), new Rectangle(Th.S(PadX), Th.S(24), Th.S(700), Th.S(30)), Th.Text, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, Desc, Th.Font(8.8f), new Rectangle(Th.S(PadX), Th.S(54), Th.S(880), Th.S(20)), Th.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }

        // ---------- 控件工厂 ----------

        protected Label Lbl(string text, int x, int y, float pt, Color color, bool bold)
        {
            Label l = new Label();
            l.Text = text;
            l.Font = bold ? Th.Bold(pt) : Th.Font(pt);
            l.ForeColor = color;
            l.BackColor = BackColor;
            l.AutoSize = true;
            l.Location = new Point(Th.S(x), Th.S(y));
            l.UseMnemonic = false;
            Controls.Add(l);
            return l;
        }

        protected Label LblWrap(string text, int x, int y, int w, int h, float pt, Color color)
        {
            Label l = new Label();
            l.Text = text;
            l.Font = Th.Font(pt);
            l.ForeColor = color;
            l.BackColor = BackColor;
            l.AutoSize = false;
            l.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            l.UseMnemonic = false;
            Controls.Add(l);
            return l;
        }

        protected Card CardAt(int x, int y, int w, int h)
        {
            Card c = new Card();
            c.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            c.BackColor = Th.Bg;
            Controls.Add(c);
            return c;
        }

        protected Btn BtnAt(Control parent, string text, BtnKind kind, int x, int y, int w, int h)
        {
            Btn b = new Btn();
            b.Text = text;
            b.Kind = kind;
            b.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            b.BackColor = parent.BackColor == Th.Bg ? (parent is Card ? ((Card)parent).Fill : Th.Bg) : parent.BackColor;
            if (parent is Card) b.BackColor = ((Card)parent).Fill;
            parent.Controls.Add(b);
            return b;
        }

        protected Field FieldAt(Control parent, string hint, int x, int y, int w, int h, bool multiline)
        {
            Field f = new Field(hint, multiline);
            f.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            f.BackColor = parent is Card ? ((Card)parent).Fill : Th.Bg;
            parent.Controls.Add(f);
            return f;
        }

        protected Combo ComboAt(Control parent, string[] items, int x, int y, int w, int h)
        {
            Combo c = new Combo();
            c.Items = items;
            c.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            c.BackColor = parent is Card ? ((Card)parent).Fill : Th.Bg;
            parent.Controls.Add(c);
            return c;
        }

        protected Seg SegAt(Control parent, string[] items, int x, int y, int w, int h)
        {
            Seg s = new Seg();
            s.Items = items;
            s.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            s.BackColor = parent is Card ? ((Card)parent).Fill : Th.Bg;
            parent.Controls.Add(s);
            return s;
        }

        protected Label MkCaption(Control parent, string text, int x, int y)
        {
            Label l = new Label();
            l.Text = text;
            l.Font = Th.Font(8.5f);
            l.ForeColor = Th.Dim;
            l.BackColor = parent is Card ? ((Card)parent).Fill : BackColor;
            l.AutoSize = true;
            l.Location = new Point(Th.S(x), Th.S(y));
            parent.Controls.Add(l);
            return l;
        }

        protected Label MkLabel(Control parent, string text, int x, int y, float pt, Color color, bool bold)
        {
            Label l = new Label();
            l.Text = text;
            l.Font = bold ? Th.Bold(pt) : Th.Font(pt);
            l.ForeColor = color;
            l.BackColor = parent is Card ? ((Card)parent).Fill : BackColor;
            l.AutoSize = true;
            l.Location = new Point(Th.S(x), Th.S(y));
            parent.Controls.Add(l);
            return l;
        }

        protected Label MkWrap(Control parent, string text, int x, int y, int w, int h, float pt, Color color)
        {
            Label l = new Label();
            l.Text = text;
            l.Font = Th.Font(pt);
            l.ForeColor = color;
            l.BackColor = parent is Card ? ((Card)parent).Fill : BackColor;
            l.AutoSize = false;
            l.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            parent.Controls.Add(l);
            return l;
        }

        protected Toggle ToggleAt(Control parent, int x, int y)
        {
            Toggle t = new Toggle();
            t.SetBounds(Th.S(x), Th.S(y), Th.S(38), Th.S(20));
            t.BackColor = parent is Card ? ((Card)parent).Fill : Th.Bg;
            parent.Controls.Add(t);
            return t;
        }

        protected Progress ProgressAt(Control parent, int x, int y, int w, int h)
        {
            Progress p = new Progress();
            p.SetBounds(Th.S(x), Th.S(y), Th.S(w), Th.S(h));
            p.BackColor = parent is Card ? ((Card)parent).Fill : Th.Bg;
            parent.Controls.Add(p);
            return p;
        }

        // ---------- 便捷操作 ----------

        protected static void CopyToClipboard(string text)
        {
            if (string.IsNullOrEmpty(text)) return;
            try
            {
                Clipboard.SetText(text);
                if (MainForm.Instance != null) MainForm.Instance.ShowToast("已复制到剪贴板", Th.Teal);
            }
            catch (Exception)
            {
                if (MainForm.Instance != null) MainForm.Instance.ShowToast("复制失败，剪贴板被占用", Th.Danger);
            }
        }

        protected static void Info(string message)
        {
            if (MainForm.Instance != null) MainForm.Instance.SetStatus(message);
        }

        protected static void Toast(string message)
        {
            if (MainForm.Instance != null) MainForm.Instance.ShowToast(message, Th.Text);
        }

        protected static void ToastOk(string message)
        {
            if (MainForm.Instance != null) MainForm.Instance.ShowToast(message, Th.Teal);
        }

        protected static void ToastErr(string message)
        {
            if (MainForm.Instance != null) MainForm.Instance.ShowToast(message, Th.Danger);
        }
    }
}
