using System;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using CipherBox.Core;

namespace CipherBox.App
{
    /// <summary>编码转换页。</summary>
    public class PageEncode : Page
    {
        private static readonly string[] Kinds =
        {
            "Base64", "Base32", "Base64URL", "十六进制 Hex", "URL 编码", "Unicode 转义",
            "HTML 实体", "二进制位串", "摩斯电码", "凯撒移位 / ROT13", "Atbash 字母反转",
            "维吉尼亚密码", "文本反转", "大小写转换"
        };

        private Combo kindBox;
        private Seg dir;
        private Field key;
        private Field input;
        private Field output;
        private Label state;

        public PageEncode()
            : base("编码转换", "Base64 / Base32 / Hex / URL / Unicode / HTML / 摩斯电码 / 古典密码 —— 快速编码与还原")
        {
        }

        protected override void Build()
        {
            Card a = CardAt(PadX, 84, 908, 112);
            MkCaption(a, "转换类型", 12, 14);
            kindBox = ComboAt(a, Kinds, 12, 34, 290, 38);

            MkCaption(a, "方向", 320, 14);
            dir = SegAt(a, new string[] { "编码", "解码" }, 320, 34, 170, 38);

            MkCaption(a, "密钥（维吉尼亚密码使用）", 508, 14);
            key = FieldAt(a, "例如 KEY", 508, 34, 210, 38, false);

            Btn run = BtnAt(a, "开始转换", BtnKind.Primary, 736, 34, 140, 38);
            run.Click += delegate { RunConvert(); };

            Card b = CardAt(PadX, 212, 908, 336);
            MkCaption(b, "输入", 12, 14);
            input = FieldAt(b, "输入要编码或解码的内容…", 12, 34, 418, 214, true);
            input.Box.TextChanged += delegate
            {
                int bytes = Encoding.UTF8.GetByteCount(input.Value);
                state.Text = bytes == 0 ? "就绪" : ("输入 " + input.Value.Length + " 字符 · " + bytes + " 字节");
            };

            MkCaption(b, "输出", 454, 14);
            output = FieldAt(b, "转换结果显示在这里", 454, 34, 418, 214, true);
            output.Box.ReadOnly = true;
            output.SetTone(Th.CardAlt, Th.Teal);

            state = MkLabel(b, "就绪", 12, 262, 8.5f, Th.Dim, false);

            Btn copy = BtnAt(b, "复制结果", BtnKind.Ghost, 12, 288, 110, 40);
            copy.Click += delegate { CopyToClipboard(output.Value); };

            Btn swap = BtnAt(b, "交换", BtnKind.Ghost, 132, 288, 90, 40);
            swap.Click += delegate
            {
                string t = input.Value;
                input.Value = output.Value;
                output.Value = t;
            };

            Btn clear = BtnAt(b, "清空", BtnKind.Ghost, 232, 288, 80, 40);
            clear.Click += delegate
            {
                input.Value = "";
                output.Value = "";
                state.Text = "就绪";
            };

            Card c = CardAt(PadX, 564, 908, 98);
            c.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Th.Setup(g);
                Icons.Draw(g, Glyph.Code, new Rectangle(Th.S(20), Th.S(18), Th.S(16), Th.S(16)), Th.Accent, Th.F(1.4f));
                TextRenderer.DrawText(g, "解码 Base64 / Hex / Base32 时，结果按 UTF-8 还原；若原文是二进制数据，可先用「十六进制」查看字节。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(12), c.Width - Th.S(70), Th.S(22)), Th.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "「凯撒移位」解码会一次性列出 26 种偏移结果，便于肉眼识别明文；「摩斯电码」以空格分隔字母、/ 分隔单词。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(38), c.Width - Th.S(70), Th.S(22)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "编码不等于加密：Base64 等只是数据表示方式，任何人都能还原，敏感信息请使用「文本加解密」。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(64), c.Width - Th.S(70), Th.S(22)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
        }

        private void RunConvert()
        {
            try
            {
                string text = input.Value;
                bool decode = dir.SelectedIndex == 1;
                output.Value = Transform(kindBox.SelectedIndex, text, decode);
                state.Text = "完成 · 输出 " + output.Value.Length + " 字符";
                ToastOk(decode ? "解码完成" : "编码完成");
            }
            catch (FormatException ex)
            {
                output.Value = "";
                state.Text = ex.Message;
                ToastErr("格式错误");
            }
            catch (Exception ex)
            {
                output.Value = "";
                state.Text = ex.Message;
                ToastErr("转换失败");
            }
        }

        private string Transform(int kind, string text, bool decode)
        {
            switch (kind)
            {
                case 0:
                    if (decode) return Codec.Utf8(Convert.FromBase64String(Strip(text)));
                    return Convert.ToBase64String(Codec.Utf8(text));
                case 1:
                    if (decode) return Codec.Utf8(Codec.FromBase32(text));
                    return Codec.ToBase32(Codec.Utf8(text));
                case 2:
                    if (decode) return Codec.Utf8(Codec.FromBase64Url(Strip(text)));
                    return Codec.ToBase64Url(Codec.Utf8(text));
                case 3:
                    if (decode) return Codec.Utf8(Codec.FromHex(text));
                    return Codec.ToHex(Codec.Utf8(text));
                case 4:
                    return decode ? Uri.UnescapeDataString(text) : Uri.EscapeDataString(text);
                case 5:
                    return decode ? UnescapeUnicode(text) : EscapeUnicode(text);
                case 6:
                    return decode ? UnescapeHtml(text) : EscapeHtml(text);
                case 7:
                    if (decode) return Codec.Utf8(Codec.FromBits(text));
                    return Codec.ToBits(Codec.Utf8(text));
                case 8:
                    return decode ? Classic.MorseDecode(text) : Classic.MorseEncode(text);
                case 9:
                    if (!decode) return Classic.Rot13(text);
                    return CaesarList(text);
                case 10:
                    return Classic.Atbash(text);
                case 11:
                    if (key.Value.Trim().Length == 0) throw new FormatException("维吉尼亚密码需要填写密钥。");
                    return Classic.Vigenere(text, key.Value.Trim(), decode);
                case 12:
                {
                    char[] arr = text.ToCharArray();
                    Array.Reverse(arr);
                    return new string(arr);
                }
                case 13:
                    return decode ? text.ToLowerInvariant() : text.ToUpperInvariant();
            }
            return text;
        }

        private static string Strip(string s)
        {
            return s.Replace("\r", "").Replace("\n", "").Replace(" ", "").Trim();
        }

        private static string CaesarList(string text)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= 25; i++)
            {
                sb.Append(i.ToString().PadLeft(2, ' ')).Append("  ").Append(Classic.Caesar(text, -i)).Append("\r\n");
            }
            return sb.ToString().TrimEnd();
        }

        private static string EscapeUnicode(string text)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in text)
            {
                sb.Append("\\u").Append(((int)c).ToString("x4"));
            }
            return sb.ToString();
        }

        private static string UnescapeUnicode(string text)
        {
            return Regex.Replace(text, @"\\u([0-9a-fA-F]{4})", m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());
        }

        private static string EscapeHtml(string text)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in text)
            {
                switch (c)
                {
                    case '&': sb.Append("&amp;"); break;
                    case '<': sb.Append("&lt;"); break;
                    case '>': sb.Append("&gt;"); break;
                    case '"': sb.Append("&quot;"); break;
                    case '\'': sb.Append("&#39;"); break;
                    default:
                        if (c < 128) sb.Append(c);
                        else sb.Append("&#").Append((int)c).Append(';');
                        break;
                }
            }
            return sb.ToString();
        }

        private static string UnescapeHtml(string text)
        {
            string s = text.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", "\"")
                .Replace("&apos;", "'").Replace("&#39;", "'").Replace("&nbsp;", " ");
            s = Regex.Replace(s, @"&#x([0-9a-fA-F]+);", m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());
            s = Regex.Replace(s, @"&#(\d+);", m => ((char)Convert.ToInt32(m.Groups[1].Value)).ToString());
            return s.Replace("&amp;", "&");
        }
    }
}
