using System;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CipherBox.Core;

namespace CipherBox.App
{
    /// <summary>哈希与摘要页。</summary>
    public class PageHash : Page
    {
        private static readonly string[] AlgNames = { "MD5", "SHA-1", "SHA-256", "SHA-384", "SHA-512" };
        private Combo algBox;
        private Combo fmtBox;
        private Field key;
        private Field input;
        private Field output;
        private Field compare;
        private Label state;
        private Label verdict;

        public PageHash()
            : base("哈希与摘要", "MD5 / SHA-1 / SHA-256 / SHA-384 / SHA-512 与 HMAC —— 用于完整性校验、消息认证与口令派生")
        {
        }

        protected override void Build()
        {
            Card a = CardAt(PadX, 84, 908, 112);
            MkCaption(a, "散列算法", 12, 14);
            algBox = ComboAt(a, AlgNames, 12, 34, 190, 38);
            algBox.SelectedIndex = 2;

            MkCaption(a, "HMAC 密钥（留空则为普通散列）", 216, 14);
            key = FieldAt(a, "可选的 HMAC 密钥", 216, 34, 230, 38, false);

            MkCaption(a, "输出格式", 460, 14);
            fmtBox = ComboAt(a, new string[] { "十六进制", "Base64" }, 460, 34, 140, 38);

            Btn calc = BtnAt(a, "计算摘要", BtnKind.Primary, 616, 34, 120, 38);
            calc.Click += delegate { Compute(true); };

            Btn copy = BtnAt(a, "复制", BtnKind.Ghost, 746, 34, 82, 38);
            copy.Click += delegate { CopyToClipboard(output.Value); };

            Card b = CardAt(PadX, 212, 908, 344);
            MkCaption(b, "输入内容", 12, 14);
            input = FieldAt(b, "输入需要计算摘要的文本，支持多行与中文…", 12, 34, 418, 190, true);
            input.Box.TextChanged += delegate
            {
                int bytes = Encoding.UTF8.GetByteCount(input.Value);
                state.Text = bytes == 0 ? "就绪" : ("输入 " + bytes + " 字节");
            };

            MkCaption(b, "摘要结果", 454, 14);
            output = FieldAt(b, "计算结果显示在这里", 454, 34, 418, 190, true);
            output.Box.ReadOnly = true;
            output.SetTone(Th.CardAlt, Th.Teal);

            state = MkLabel(b, "就绪", 12, 236, 8.5f, Th.Dim, false);

            MkCaption(b, "哈希比对（可选）", 12, 262);
            compare = FieldAt(b, "粘贴待比对的哈希值，用于校验文件或口令是否一致", 12, 282, 470, 38, false);
            Btn cmp = BtnAt(b, "比对", BtnKind.Ghost, 494, 282, 96, 38);
            cmp.Click += delegate { Compare(); };
            verdict = MkLabel(b, "", 604, 292, 9f, Th.Muted, false);

            Card c = CardAt(PadX, 572, 908, 90);
            c.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Th.Setup(g);
                Icons.Draw(g, Glyph.Shield, new Rectangle(Th.S(20), Th.S(18), Th.S(16), Th.S(16)), Th.Teal, Th.F(1.4f));
                TextRenderer.DrawText(g, "摘要长度对照：MD5 32 位 · SHA-1 40 位 · SHA-256 64 位 · SHA-384 96 位 · SHA-512 128 位（十六进制字符数）", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(12), c.Width - Th.S(70), Th.S(22)), Th.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "哈希不可逆，只能用于校验；存储口令请使用 PBKDF2 / bcrypt / Argon2 等带盐慢哈希，而不是 MD5 或 SHA-1。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(38), c.Width - Th.S(70), Th.S(22)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "HMAC 需要密钥参与运算，可同时验证完整性与来源真实性。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(64), c.Width - Th.S(70), Th.S(22)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
        }

        private string AlgKey()
        {
            return AlgNames[algBox.SelectedIndex].Replace("-", "");
        }

        private void Compute(bool toast)
        {
            try
            {
                Stopwatch sw = Stopwatch.StartNew();
                byte[] data = Codec.Utf8(input.Value);
                string k = key.Value;
                byte[] digest;
                if (k.Length > 0)
                {
                    digest = Digests.HmacBytes(AlgKey(), data, k);
                }
                else
                {
                    using (System.Security.Cryptography.HashAlgorithm h = Digests.CreateHash(AlgKey()))
                    {
                        digest = h.ComputeHash(data);
                    }
                }
                sw.Stop();
                output.Value = fmtBox.SelectedIndex == 1 ? Convert.ToBase64String(digest) : Codec.ToHex(digest);
                string mode = k.Length > 0 ? "HMAC-" : "";
                state.Text = mode + AlgKey() + " · " + digest.Length + " 字节 · 耗时 " + sw.Elapsed.TotalMilliseconds.ToString("0.00") + " ms";
                if (toast) ToastOk("摘要计算完成");
            }
            catch (Exception ex)
            {
                ToastErr("计算失败");
                state.Text = ex.Message;
            }
        }

        private void Compare()
        {
            if (output.Value.Length == 0) Compute(false);
            string target = compare.Value.Trim();
            if (target.Length == 0)
            {
                verdict.Text = "请先粘贴待比对的哈希值";
                verdict.ForeColor = Th.Dim;
                return;
            }
            bool same = string.Equals(target, output.Value.Trim(), StringComparison.OrdinalIgnoreCase);
            if (same)
            {
                verdict.Text = "✔ 一致，内容相同";
                verdict.ForeColor = Th.Teal;
                ToastOk("比对一致");
            }
            else
            {
                verdict.Text = "✘ 不一致";
                verdict.ForeColor = Th.Danger;
                ToastErr("比对结果不一致");
            }
        }
    }
}
