using System;
using System.Drawing;
using System.Windows.Forms;
using CipherBox.Core;

namespace CipherBox.App
{
    /// <summary>密码中心：强度检测、随机生成、常见口令库与哈希反查。</summary>
    public class PagePasswordTools : Page
    {
        private Field check;
        private Progress meter;
        private Label score;
        private Label level;
        private Label tips;
        private Label count;
        private Field generated;
        private Label lengthLabel;
        private int length = 20;
        private Toggle tUpper;
        private Toggle tLower;
        private Toggle tDigit;
        private Toggle tSymbol;
        private Toggle tAvoid;
        private Field hashBox;
        private Label hashResult;

        public PagePasswordTools()
            : base("密码中心", "弱口令自查、强度评估、随机口令生成，以及内置常见口令库的哈希反查")
        {
        }

        protected override void Build()
        {
            Card left = CardAt(PadX, 84, 440, 336);

            MkCaption(left, "待检测口令", 12, 14);
            check = FieldAt(left, "输入要检测的口令", 12, 34, 300, 38, false);
            check.EnablePasswordToggle();
            check.Box.TextChanged += delegate { Evaluate(); };

            Btn run = BtnAt(left, "立即检测", BtnKind.Primary, 322, 34, 106, 38);
            run.Click += delegate { Evaluate(); };

            meter = ProgressAt(left, 12, 86, 416, 8);
            meter.Value = 0;

            score = MkLabel(left, "0", 12, 100, 24f, Th.Dim, true);
            level = MkLabel(left, "等待检测", 80, 112, 9.5f, Th.Dim, false);

            MkCaption(left, "改进建议", 12, 150);
            tips = MkWrap(left, "输入口令后自动分析：长度、字符种类、常见弱口令命中、重复与顺序模式。", 12, 168, 416, 196, 8.8f, Th.Muted);

            Card right = CardAt(488, 84, 452, 336);

            MkCaption(right, "长度", 12, 14);
            Btn minus = BtnAt(right, "−", BtnKind.Ghost, 12, 34, 32, 38);
            minus.Font = Th.Font(12f);
            minus.Click += delegate { SetLength(length - 1); };
            lengthLabel = MkLabel(right, "20", 50, 40, 12f, Th.Text, true);
            Btn plus = BtnAt(right, "+", BtnKind.Ghost, 84, 34, 32, 38);
            plus.Font = Th.Font(12f);
            plus.Click += delegate { SetLength(length + 1); };

            MkCaption(right, "字符集", 132, 14);
            MkLabel(right, "大写", 132, 40, 9f, Th.Text, false);
            tUpper = ToggleAt(right, 170, 42);
            tUpper.Checked = true;
            MkLabel(right, "小写", 220, 40, 9f, Th.Text, false);
            tLower = ToggleAt(right, 258, 42);
            tLower.Checked = true;
            MkLabel(right, "数字", 304, 40, 9f, Th.Text, false);
            tDigit = ToggleAt(right, 342, 42);
            tDigit.Checked = true;

            MkLabel(right, "符号", 132, 80, 9f, Th.Text, false);
            tSymbol = ToggleAt(right, 170, 82);
            tSymbol.Checked = true;
            MkLabel(right, "排除易混淆字符（O0Il1）", 220, 80, 9f, Th.Text, false);
            tAvoid = ToggleAt(right, 402, 82);
            tAvoid.Checked = true;

            Btn gen = BtnAt(right, "生成口令", BtnKind.Primary, 12, 116, 130, 40);
            gen.Click += delegate { Generate(); };

            MkCaption(right, "生成结果", 12, 168);
            generated = FieldAt(right, "点击「生成口令」", 12, 186, 318, 40, false);
            generated.Box.ReadOnly = true;
            generated.SetTone(Th.CardAlt, Th.Teal);
            generated.Box.Font = Th.Mono(11f);

            Btn copy = BtnAt(right, "复制", BtnKind.Ghost, 338, 186, 90, 40);
            copy.Click += delegate { CopyToClipboard(generated.Value); };

            MkWrap(right, "口令使用加密安全的随机源（RNGCryptoServiceProvider）生成，保证每类字符至少出现一次。",
                12, 240, 416, 60, 8.5f, Th.Dim);

            Card bottom = CardAt(PadX, 436, 908, 226);

            MkLabel(bottom, "内置常见口令库", 12, 12, 10f, Th.Text, true);
            count = MkLabel(bottom, "", 12, 36, 8.5f, Th.Dim, false);
            UpdateCount();

            MkCaption(bottom, "哈希反查（支持 MD5 / SHA-1 / SHA-256 / SHA-512 十六进制摘要）", 12, 66);
            hashBox = FieldAt(bottom, "粘贴 32 / 40 / 64 / 128 位十六进制哈希值", 12, 86, 420, 38, false);
            hashBox.Box.Font = Th.Mono(9.5f);
            Btn look = BtnAt(bottom, "反查", BtnKind.Primary, 444, 86, 100, 38);
            look.Click += delegate { Lookup(); };
            hashResult = MkLabel(bottom, "", 556, 96, 9f, Th.Muted, false);

            Btn import = BtnAt(bottom, "导入自定义字典", BtnKind.Ghost, 12, 140, 150, 32);
            import.Click += delegate { ImportDict(); };

            MkCaption(bottom, "支持每行一条口令的 .txt / .dic 文件，导入后参与强度比对与哈希反查（仅在本机内存中）。", 170, 146);
            bottom.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Th.Setup(g);
                using (Pen p = new Pen(Th.BorderSoft))
                {
                    g.DrawLine(p, Th.S(12), Th.S(184), bottom.Width - Th.S(12), Th.S(184));
                }
                TextRenderer.DrawText(g, "常见口令库仅用于安全自查：它能告诉你某个口令是否早已出现在公开字典中。请勿用于未授权的口令猜解。",
                    Th.Font(8.5f), new Rectangle(Th.S(12), Th.S(192), bottom.Width - Th.S(24), Th.S(20)), Th.Dim,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };
        }

        private void UpdateCount()
        {
            count.Text = "当前收录 " + PasswordTools.Count + " 条弱口令（含内置与自定义），覆盖数字串、键盘序列、姓名与常见年份组合";
        }

        private void SetLength(int v)
        {
            length = Math.Max(4, Math.Min(64, v));
            lengthLabel.Text = length.ToString();
        }

        private void Evaluate()
        {
            StrengthResult r = PasswordTools.Evaluate(check.Value);
            meter.Value = r.Score / 100.0;
            score.Text = r.Score.ToString();
            level.Text = r.Label + (r.IsCommon ? " · 命中常见口令库" : "");
            Color c;
            Color c2;
            if (r.Score < 20) { c = Th.Hex("#FF5C5C"); c2 = Th.Hex("#FF8A5B"); }
            else if (r.Score < 40) { c = Th.Hex("#FF8A5B"); c2 = Th.Warn; }
            else if (r.Score < 60) { c = Th.Warn; c2 = Th.Hex("#F5D76E"); }
            else if (r.Score < 80) { c = Th.Accent; c2 = Th.Violet; }
            else { c = Th.Teal; c2 = Th.Accent; }
            score.ForeColor = r.Label == "空" ? Th.Dim : c;
            level.ForeColor = r.Label == "空" ? Th.Dim : Th.Muted;
            meter.ColorA = c;
            meter.ColorB = c2;
            meter.Invalidate();

            if (check.Value.Length == 0)
            {
                tips.Text = "输入口令后自动分析：长度、字符种类、常见弱口令命中、重复与顺序模式。";
                tips.ForeColor = Th.Muted;
                return;
            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (string t in r.Tips)
            {
                sb.Append("· ").Append(t).Append("\r\n");
            }
            sb.Append("\r\n估算熵值：").Append(r.Entropy.ToString("0.0")).Append(" bit（仅供参考）");
            tips.Text = sb.ToString();
            tips.ForeColor = r.IsCommon ? Th.Hex("#FFB4A8") : Th.Muted;
        }

        private void Generate()
        {
            if (!tUpper.Checked && !tLower.Checked && !tDigit.Checked && !tSymbol.Checked)
            {
                ToastErr("至少选择一种字符类型");
                return;
            }
            try
            {
                generated.Value = PasswordTools.Generate(length, tUpper.Checked, tLower.Checked, tDigit.Checked, tSymbol.Checked, tAvoid.Checked);
                ToastOk("已生成 " + length + " 位随机口令");
            }
            catch (Exception ex)
            {
                ToastErr("生成失败");
                MainForm.Instance.SetStatus(ex.Message);
            }
        }

        private void Lookup()
        {
            string hash = hashBox.Value.Trim();
            if (hash.Length == 0)
            {
                hashResult.Text = "请先粘贴哈希值";
                hashResult.ForeColor = Th.Dim;
                return;
            }
            string alg = PasswordTools.DetectHashAlg(hash);
            if (alg == null)
            {
                hashResult.Text = "无法识别的哈希格式（应为 32/40/64/96/128 位十六进制）";
                hashResult.ForeColor = Th.Warn;
                return;
            }
            int tried;
            string plain = PasswordTools.LookupHash(hash, out alg, out tried);
            if (plain != null)
            {
                hashResult.Text = "✔ 命中（" + alg + "）：" + plain;
                hashResult.ForeColor = Th.Teal;
                ToastOk("已在字典中命中该口令");
            }
            else
            {
                hashResult.Text = "未命中（已比对 " + tried + " 条，" + alg + "）";
                hashResult.ForeColor = Th.Muted;
            }
        }

        private void ImportDict()
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "选择口令字典";
                dlg.Filter = "文本文件 (*.txt;*.dic)|*.txt;*.dic|所有文件 (*.*)|*.*";
                if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;
                try
                {
                    PasswordTools.AddFromFile(dlg.FileName);
                    UpdateCount();
                    ToastOk("字典导入成功，共 " + PasswordTools.Count + " 条");
                }
                catch (Exception ex)
                {
                    ToastErr("导入失败");
                    MainForm.Instance.SetStatus(ex.Message);
                }
            }
        }
    }
}
