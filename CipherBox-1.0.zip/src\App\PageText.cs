using System;
using System.Diagnostics;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using CipherBox.Core;

namespace CipherBox.App
{
    /// <summary>文本加解密页。</summary>
    public class PageText : Page
    {
        private static readonly string[] AlgNames = { "AES-128", "AES-192", "AES-256", "DES", "3DES", "RC4", "XOR" };
        private Seg mode;
        private Combo algBox;
        private Combo encBox;
        private Field pass;
        private Field input;
        private Field output;
        private Btn runBtn;
        private Label inputLabel;
        private Label state;

        public PageText()
            : base("文本加解密", "AES / DES / 3DES / RC4 / XOR —— 口令经 PBKDF2-SHA256（20000 次迭代）派生密钥，密文自带随机盐与 IV")
        {
        }

        protected override void Build()
        {
            Card a = CardAt(PadX, 84, 908, 128);

            Caption(a, "加密算法", 12, 14);
            algBox = ComboAt(a, AlgNames, 12, 34, 224, 38);
            algBox.Changed += delegate { SyncMode(); };

            Caption(a, "输出编码", 248, 14);
            encBox = ComboAt(a, new string[] { "Base64", "十六进制" }, 248, 34, 132, 38);

            Caption(a, "工作模式", 392, 14);
            mode = SegAt(a, new string[] { "CBC", "ECB" }, 392, 34, 160, 38);

            Caption(a, "口令 / 密钥", 564, 14);
            pass = FieldAt(a, "输入口令", 564, 34, 232, 38, false);
            pass.EnablePasswordToggle();

            Btn rnd = BtnAt(a, "随机", BtnKind.Ghost, 808, 34, 88, 38);
            rnd.Click += delegate
            {
                pass.Value = PasswordTools.Generate(20, true, true, true, true, true);
                ToastOk("已生成随机口令");
            };

            Card b = CardAt(PadX, 228, 908, 336);
            inputLabel = Caption(b, "输入内容（明文 / 密文）", 12, 14);
            input = FieldAt(b, "在此粘贴要加密的明文，或要解密的密文…", 12, 34, 418, 190, true);
            input.Box.TextChanged += delegate { Inspect(); };

            Caption(b, "输出结果", 454, 14);
            output = FieldAt(b, "结果会显示在这里", 454, 34, 418, 190, true);
            output.Box.ReadOnly = true;
            output.SetTone(Th.CardAlt, Th.Teal);

            state = MkLabel(b, "就绪", 12, 238, 8.5f, Th.Dim, false);

            runBtn = BtnAt(b, "加密", BtnKind.Primary, 12, 268, 120, 40);
            runBtn.Click += delegate { Run(false); };

            Btn decBtn = BtnAt(b, "解密", BtnKind.Ghost, 140, 268, 100, 40);
            decBtn.Click += delegate { Run(true); };

            Btn swap = BtnAt(b, "交换", BtnKind.Ghost, 248, 268, 92, 40);
            swap.Click += delegate
            {
                string t = input.Value;
                input.Value = output.Value;
                output.Value = t;
            };

            Btn copy = BtnAt(b, "复制结果", BtnKind.Ghost, 348, 268, 108, 40);
            copy.Click += delegate { CopyToClipboard(output.Value); };

            Btn clear = BtnAt(b, "清空", BtnKind.Ghost, 464, 268, 84, 40);
            clear.Click += delegate
            {
                input.Value = "";
                output.Value = "";
                state.Text = "就绪";
            };

            mode.Changed += delegate { Invalidate(); };

            Card tip = CardAt(PadX, 580, 908, 82);
            tip.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Th.Setup(g);
                Icons.Draw(g, Glyph.Info, new Rectangle(Th.S(20), Th.S(20), Th.S(16), Th.S(16)), Th.Accent, Th.F(1.4f));
                TextRenderer.DrawText(g, "相同口令每次加密得到的密文都不同（随机盐 + 随机 IV），这是预期行为。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(14), tip.Width - Th.S(70), Th.S(22)), Th.Muted, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(g, "解密失败通常意味着口令错误或密文被改动；请确认算法、模式与编码三者与加密时一致。", Th.Font(8.8f),
                    new Rectangle(Th.S(46), Th.S(40), tip.Width - Th.S(70), Th.S(22)), Th.Dim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            };

            SyncMode();
            state.Text = "就绪";
        }

        private Label Caption(Control parent, string text, int x, int y)
        {
            Label l = new Label();
            l.Text = text;
            l.Font = Th.Font(8.5f);
            l.ForeColor = Th.Dim;
            l.BackColor = parent is Card ? ((Card)parent).Fill : Th.Bg;
            l.AutoSize = true;
            l.Location = new Point(Th.S(x), Th.S(y));
            parent.Controls.Add(l);
            return l;
        }

        private void SyncMode()
        {
            bool block = algBox.SelectedIndex <= 4;
            mode.Enabled = block;
            mode.Invalidate();
        }

        private void Inspect()
        {
            if (input == null || state == null) return;
            int bytes = Encoding.UTF8.GetByteCount(input.Value);
            state.Text = bytes == 0 ? "就绪" : ("输入 " + input.Value.Length + " 字符 · " + bytes + " 字节");
        }

        private int AlgoId()
        {
            switch (algBox.SelectedIndex)
            {
                case 3: return Algs.Des;
                case 4: return Algs.TripleDes;
                case 5: return Algs.Rc4;
                case 6: return Algs.Xor;
                default: return Algs.Aes;
            }
        }

        private int KeyBits()
        {
            switch (algBox.SelectedIndex)
            {
                case 1: return 192;
                case 3: return 64;
                case 4: return 192;
                default: return 256;
            }
        }

        private CipherMode CurrentMode()
        {
            return mode.SelectedIndex == 1 ? CipherMode.ECB : CipherMode.CBC;
        }

        private void Run(bool decrypt)
        {
            Stopwatch sw = Stopwatch.StartNew();
            try
            {
                string key = pass.Value;
                if (key.Length == 0)
                {
                    ToastErr("请先输入口令");
                    pass.Box.Focus();
                    return;
                }

                int algId = AlgoId();
                int bits = KeyBits();
                bool hex = encBox.SelectedIndex == 1;

                if (!decrypt)
                {
                    byte[] payload = Symmetric.Encrypt(Codec.Utf8(input.Value), key, algId, bits, CurrentMode());
                    output.Value = hex ? Codec.ToHex(payload) : Convert.ToBase64String(payload);
                    sw.Stop();
                    state.Text = "加密完成 · 密文 " + payload.Length + " 字节 · 耗时 " + sw.Elapsed.TotalMilliseconds.ToString("0.0") + " ms";
                    ToastOk("加密完成");
                }
                else
                {
                    string text = input.Value.Replace("\r", "").Replace("\n", "").Replace(" ", "").Trim();
                    if (text.Length == 0)
                    {
                        ToastErr("请先粘贴密文");
                        return;
                    }
                    byte[] payload = hex ? Codec.FromHex(text) : Convert.FromBase64String(text);
                    byte[] plain = Symmetric.Decrypt(payload, key, algId, bits);
                    output.Value = Codec.Utf8(plain);
                    sw.Stop();
                    state.Text = "解密完成 · 明文 " + plain.Length + " 字节 · 耗时 " + sw.Elapsed.TotalMilliseconds.ToString("0.0") + " ms";
                    ToastOk("解密完成");
                }
            }
            catch (CryptographicException)
            {
                ToastErr("解密失败：口令错误或密文已损坏");
                state.Text = "解密失败：填充校验未通过，通常表示口令不正确";
            }
            catch (FormatException ex)
            {
                ToastErr("格式错误");
                state.Text = ex.Message;
            }
            catch (Exception ex)
            {
                ToastErr("处理失败");
                state.Text = ex.Message;
            }
            finally
            {
                Invalidate();
            }
        }
    }
}
