using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace CipherBox.App
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e)
            {
                ShowError(e.Exception);
            };
            AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e)
            {
                ShowError(e.ExceptionObject as Exception);
            };

            try
            {
                using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
                {
                    Th.Scale = g.DpiX / 96f;
                }
            }
            catch (Exception)
            {
                Th.Scale = 1f;
            }
            if (Th.Scale < 0.75f || Th.Scale > 4f) Th.Scale = 1f;

            Application.Run(new MainForm());
        }

        private static void ShowError(Exception ex)
        {
            if (ex == null) return;
            string message = "程序遇到未处理的异常：\r\n\r\n" + ex.Message + "\r\n\r\n" + ex.StackTrace;
            try
            {
                MessageBox.Show(message, "CipherBox", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {
            }
        }
    }
}
