using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace CipherBox.App
{
    /// <summary>主题：配色、字体、DPI 缩放与圆角绘制。</summary>
    public static class Th
    {
        public static float Scale = 1f;

        public static int S(int v)
        {
            return (int)Math.Round(v * Scale);
        }

        public static float F(float v)
        {
            return v * Scale;
        }

        /// <summary>磅值转像素：1pt = 96/72 px，再乘以布局缩放，避免与系统 DPI 二次放大。</summary>
        private static float Px(float pt)
        {
            return pt * (96f / 72f) * Scale;
        }

        public static Font Font(float pt)
        {
            return new Font("Microsoft YaHei UI", Px(pt), FontStyle.Regular, GraphicsUnit.Pixel);
        }

        public static Font Bold(float pt)
        {
            return new Font("Microsoft YaHei UI", Px(pt), FontStyle.Bold, GraphicsUnit.Pixel);
        }

        public static Font Mono(float pt)
        {
            return new Font("Consolas", Px(pt), FontStyle.Regular, GraphicsUnit.Pixel);
        }

        public static Font MonoBold(float pt)
        {
            return new Font("Consolas", Px(pt), FontStyle.Bold, GraphicsUnit.Pixel);
        }

        public static Color Hex(string hex)
        {
            return ColorTranslator.FromHtml(hex);
        }

        public static readonly Color Bg = Hex("#0E131C");
        public static readonly Color Sidebar = Hex("#0A0F17");
        public static readonly Color Card = Hex("#151C28");
        public static readonly Color CardAlt = Hex("#121925");
        public static readonly Color CardHover = Hex("#1A2231");
        public static readonly Color Input = Hex("#0F1620");
        public static readonly Color InputFocus = Hex("#111A26");
        public static readonly Color Border = Hex("#243044");
        public static readonly Color BorderSoft = Hex("#1B2432");
        public static readonly Color Text = Hex("#E8EEF8");
        public static readonly Color Muted = Hex("#8896AC");
        public static readonly Color Dim = Hex("#5D6A7E");
        public static readonly Color Accent = Hex("#4B8DFF");
        public static readonly Color AccentDeep = Hex("#2F6FE0");
        public static readonly Color AccentSoft = Hex("#1B2C4A");
        public static readonly Color Teal = Hex("#22D3A6");
        public static readonly Color Danger = Hex("#FF6B6B");
        public static readonly Color Warn = Hex("#FFB020");
        public static readonly Color Violet = Hex("#8B7BFF");

        public static GraphicsPath Round(Rectangle r, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0)
            {
                path.AddRectangle(r);
                return path;
            }
            int d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static void FillRound(Graphics g, Rectangle r, int radius, Color color)
        {
            using (GraphicsPath p = Round(r, radius))
            using (SolidBrush b = new SolidBrush(color))
            {
                g.FillPath(b, p);
            }
        }

        public static void DrawRound(Graphics g, Rectangle r, int radius, Color color)
        {
            DrawRound(g, r, radius, color, 1f);
        }

        public static void DrawRound(Graphics g, Rectangle r, int radius, Color color, float width)
        {
            using (GraphicsPath p = Round(r, radius))
            using (Pen pen = new Pen(color, width))
            {
                pen.Alignment = PenAlignment.Inset;
                g.DrawPath(pen, p);
            }
        }

        public static void FillRoundGradient(Graphics g, Rectangle r, int radius, Color a, Color b, float angle)
        {
            using (GraphicsPath p = Round(r, radius))
            using (LinearGradientBrush br = new LinearGradientBrush(r, a, b, angle))
            {
                g.FillPath(br, p);
            }
        }

        public static void Setup(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        }
    }

    public enum Glyph
    {
        Lock,
        Hash,
        Code,
        Key,
        Shield,
        File,
        Info
    }

    /// <summary>线性矢量小图标，避免依赖图标字体。</summary>
    public static class Icons
    {
        public static void Draw(Graphics g, Glyph glyph, RectangleF r, Color color, float width)
        {
            using (Pen pen = new Pen(color, width))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                pen.LineJoin = LineJoin.Round;
                float x = r.X, y = r.Y, w = r.Width, h = r.Height;
                switch (glyph)
                {
                    case Glyph.Lock:
                    {
                        RectangleF body = new RectangleF(x + w * 0.2f, y + h * 0.45f, w * 0.6f, h * 0.42f);
                        using (GraphicsPath p = Th.Round(Rectangle.Round(body), (int)(w * 0.1f)))
                        {
                            g.DrawPath(pen, p);
                        }
                        g.DrawArc(pen, x + w * 0.32f, y + h * 0.16f, w * 0.36f, h * 0.44f, 180, 180);
                        break;
                    }
                    case Glyph.Hash:
                    {
                        g.DrawLine(pen, x + w * 0.34f, y + h * 0.15f, x + w * 0.26f, y + h * 0.85f);
                        g.DrawLine(pen, x + w * 0.7f, y + h * 0.15f, x + w * 0.62f, y + h * 0.85f);
                        g.DrawLine(pen, x + w * 0.15f, y + h * 0.38f, x + w * 0.85f, y + h * 0.38f);
                        g.DrawLine(pen, x + w * 0.15f, y + h * 0.64f, x + w * 0.85f, y + h * 0.64f);
                        break;
                    }
                    case Glyph.Code:
                    {
                        g.DrawLines(pen, new PointF[]
                        {
                            new PointF(x + w * 0.38f, y + h * 0.2f),
                            new PointF(x + w * 0.12f, y + h * 0.5f),
                            new PointF(x + w * 0.38f, y + h * 0.8f)
                        });
                        g.DrawLines(pen, new PointF[]
                        {
                            new PointF(x + w * 0.62f, y + h * 0.2f),
                            new PointF(x + w * 0.88f, y + h * 0.5f),
                            new PointF(x + w * 0.62f, y + h * 0.8f)
                        });
                        break;
                    }
                    case Glyph.Key:
                    {
                        g.DrawEllipse(pen, x + w * 0.12f, y + h * 0.3f, w * 0.34f, h * 0.4f);
                        g.DrawLine(pen, x + w * 0.44f, y + h * 0.5f, x + w * 0.9f, y + h * 0.5f);
                        g.DrawLine(pen, x + w * 0.9f, y + h * 0.5f, x + w * 0.9f, y + h * 0.72f);
                        g.DrawLine(pen, x + w * 0.72f, y + h * 0.5f, x + w * 0.72f, y + h * 0.68f);
                        break;
                    }
                    case Glyph.Shield:
                    {
                        g.DrawLines(pen, new PointF[]
                        {
                            new PointF(x + w * 0.5f, y + h * 0.1f),
                            new PointF(x + w * 0.88f, y + h * 0.24f),
                            new PointF(x + w * 0.88f, y + h * 0.52f),
                            new PointF(x + w * 0.5f, y + h * 0.9f),
                            new PointF(x + w * 0.12f, y + h * 0.52f),
                            new PointF(x + w * 0.12f, y + h * 0.24f)
                        });
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.1f, x + w * 0.12f, y + h * 0.24f);
                        break;
                    }
                    case Glyph.File:
                    {
                        using (GraphicsPath p = new GraphicsPath())
                        {
                            p.AddLines(new PointF[]
                            {
                                new PointF(x + w * 0.22f, y + h * 0.12f),
                                new PointF(x + w * 0.6f, y + h * 0.12f),
                                new PointF(x + w * 0.78f, y + h * 0.3f),
                                new PointF(x + w * 0.78f, y + h * 0.88f),
                                new PointF(x + w * 0.22f, y + h * 0.88f)
                            });
                            p.CloseFigure();
                            g.DrawPath(pen, p);
                        }
                        g.DrawLine(pen, x + w * 0.6f, y + h * 0.12f, x + w * 0.6f, y + h * 0.3f);
                        g.DrawLine(pen, x + w * 0.6f, y + h * 0.3f, x + w * 0.78f, y + h * 0.3f);
                        break;
                    }
                    case Glyph.Info:
                    {
                        g.DrawEllipse(pen, x + w * 0.12f, y + h * 0.12f, w * 0.76f, h * 0.76f);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.44f, x + w * 0.5f, y + h * 0.7f);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.28f, x + w * 0.5f, y + h * 0.31f);
                        break;
                    }
                }
            }
        }
    }
}
