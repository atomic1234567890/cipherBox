﻿using System;
namespace CipherBox.App
{
    public class PageText : Page
    {
        public PageText() : base("文本加解密", "stub") { }
        protected override void Build() { }
    }
}
