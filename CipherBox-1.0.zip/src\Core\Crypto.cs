using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CipherBox.Core
{
    public static class Algs
    {
        public const int Aes = 0;
        public const int Des = 1;
        public const int TripleDes = 2;
        public const int Rc4 = 3;
        public const int Xor = 4;

        public static string Name(int alg)
        {
            switch (alg)
            {
                case Aes: return "AES";
                case Des: return "DES";
                case TripleDes: return "3DES";
                case Rc4: return "RC4";
                case Xor: return "XOR";
            }
            return "?";
        }
    }

    /// <summary>字节与文本编码的公共助手。</summary>
    public static class Codec
    {
        private const string B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

        public static byte[] Utf8(string s)
        {
            return Encoding.UTF8.GetBytes(s);
        }

        public static string Utf8(byte[] b)
        {
            return Encoding.UTF8.GetString(b);
        }

        public static string ToHex(byte[] data)
        {
            if (data == null) return "";
            StringBuilder sb = new StringBuilder(data.Length * 2);
            for (int i = 0; i < data.Length; i++) sb.Append(data[i].ToString("x2", CultureInfo.InvariantCulture));
            return sb.ToString();
        }

        public static string ToHexUpper(byte[] data)
        {
            return ToHex(data).ToUpperInvariant();
        }

        public static byte[] FromHex(string hex)
        {
            if (hex == null) throw new FormatException("十六进制内容为空。");
            StringBuilder clean = new StringBuilder(hex.Length);
            foreach (char c in hex)
            {
                if (char.IsWhiteSpace(c) || c == '-' || c == ':' || c == ',') continue;
                if (c == '0' && clean.Length == 0 && false) continue;
                clean.Append(c);
            }
            string s = clean.ToString();
            if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase)) s = s.Substring(2);
            if (s.Length == 0) return new byte[0];
            if (s.Length % 2 != 0) throw new FormatException("十六进制长度必须为偶数（当前 " + s.Length + " 位）。");
            byte[] outBuf = new byte[s.Length / 2];
            for (int i = 0; i < outBuf.Length; i++)
            {
                int hi = HexVal(s[i * 2]);
                int lo = HexVal(s[i * 2 + 1]);
                if (hi < 0 || lo < 0) throw new FormatException("包含非法的十六进制字符：“" + s[i * 2] + s[i * 2 + 1] + "”。");
                outBuf[i] = (byte)((hi << 4) | lo);
            }
            return outBuf;
        }

        private static int HexVal(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        }

        public static string ToBase32(byte[] data)
        {
            if (data == null || data.Length == 0) return "";
            StringBuilder sb = new StringBuilder((data.Length * 8 + 4) / 5);
            int buffer = 0;
            int bitsLeft = 0;
            foreach (byte b in data)
            {
                buffer = (buffer << 8) | b;
                bitsLeft += 8;
                while (bitsLeft >= 5)
                {
                    sb.Append(B32[(buffer >> (bitsLeft - 5)) & 31]);
                    bitsLeft -= 5;
                }
            }
            if (bitsLeft > 0) sb.Append(B32[(buffer << (5 - bitsLeft)) & 31]);
            return sb.ToString();
        }

        public static byte[] FromBase32(string text)
        {
            if (text == null) throw new FormatException("Base32 内容为空。");
            string s = text.Trim().TrimEnd('=').Replace(" ", "").Replace("\r", "").Replace("\n", "").ToUpperInvariant();
            if (s.Length == 0) return new byte[0];
            int buffer = 0;
            int bitsLeft = 0;
            MemoryStream ms = new MemoryStream();
            foreach (char c in s)
            {
                int idx = B32.IndexOf(c);
                if (idx < 0) throw new FormatException("非法的 Base32 字符：“" + c + "”。");
                buffer = (buffer << 5) | idx;
                bitsLeft += 5;
                if (bitsLeft >= 8)
                {
                    ms.WriteByte((byte)((buffer >> (bitsLeft - 8)) & 0xFF));
                    bitsLeft -= 8;
                }
            }
            return ms.ToArray();
        }

        public static string ToBase64Url(byte[] data)
        {
            return Convert.ToBase64String(data).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        public static byte[] FromBase64Url(string text)
        {
            string s = text.Trim().Replace('-', '+').Replace('_', '/');
            switch (s.Length % 4)
            {
                case 2: s += "=="; break;
                case 3: s += "="; break;
            }
            return Convert.FromBase64String(s);
        }

        public static string ToBits(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 8);
            foreach (byte b in data)
            {
                for (int i = 7; i >= 0; i--) sb.Append(((b >> i) & 1) == 1 ? '1' : '0');
            }
            return sb.ToString();
        }

        public static byte[] FromBits(string bits)
        {
            StringBuilder clean = new StringBuilder();
            foreach (char c in bits)
            {
                if (c == '0' || c == '1') clean.Append(c);
            }
            if (clean.Length % 8 != 0) throw new FormatException("二进制长度必须是 8 的整数倍（当前 " + clean.Length + " 位）。");
            byte[] buf = new byte[clean.Length / 8];
            for (int i = 0; i < buf.Length; i++)
            {
                int v = 0;
                for (int j = 0; j < 8; j++) v = (v << 1) | (clean[i * 8 + j] == '1' ? 1 : 0);
                buf[i] = (byte)v;
            }
            return buf;
        }

        public static byte[] RandomBytes(int count)
        {
            byte[] b = new byte[count];
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(b);
            }
            return b;
        }

        public static string Truncate(string s, int max)
        {
            if (s == null) return "";
            return s.Length <= max ? s : s.Substring(0, max);
        }
    }

    /// <summary>对称加密：AES / DES / 3DES / RC4 / XOR。统一封装格式：0x01 | salt(16) | iv(16, 流密码无) | 密文。</summary>
    public static class Symmetric
    {
        public const int SaltSize = 16;
        public const int IvSize = 16;
        public const int KdfIterations = 20000;
        private const byte FormatVersion = 1;

        public static byte[] DeriveKey(string password, byte[] salt, int length)
        {
            if (password == null) password = "";
            try
            {
                using (Rfc2898DeriveBytes kdf = new Rfc2898DeriveBytes(password, salt, KdfIterations, HashAlgorithmName.SHA256))
                {
                    return kdf.GetBytes(length);
                }
            }
            catch (Exception)
            {
                // 旧框架回退（PBKDF2-SHA1）。
                using (Rfc2898DeriveBytes kdf = new Rfc2898DeriveBytes(password, salt, KdfIterations))
                {
                    return kdf.GetBytes(length);
                }
            }
        }

        public static byte[] Encrypt(byte[] plain, string password, int alg, int keyBits, CipherMode mode)
        {
            byte[] salt = Codec.RandomBytes(SaltSize);
            switch (alg)
            {
                case Algs.Aes:
                    return EncryptBlockCipher(new AesCryptoServiceProvider(), cipher =>
                    {
                        cipher.KeySize = keyBits;
                        return DeriveKey(password, salt, keyBits / 8);
                    }, plain, salt, mode);
                case Algs.Des:
                    return EncryptBlockCipher(new DESCryptoServiceProvider(), cipher => DeriveKey(password, salt, 8), plain, salt, mode);
                case Algs.TripleDes:
                    return EncryptBlockCipher(new TripleDESCryptoServiceProvider(), cipher => DeriveKey(password, salt, 24), plain, salt, mode);
                case Algs.Rc4:
                {
                    byte[] key = DeriveKey(password, salt, 16);
                    return Pack(salt, null, Rc4Apply(plain, key), CipherMode.CBC);
                }
                case Algs.Xor:
                {
                    byte[] key = DeriveKey(password, salt, 16);
                    return Pack(salt, null, XorApply(plain, key), CipherMode.CBC);
                }
            }
            throw new ArgumentException("不支持的算法。");
        }

        public static byte[] Decrypt(byte[] payload, string password, int alg, int keyBits)
        {
            byte[] salt, iv, ct;
            Unpack(payload, out salt, out iv, out ct);
            switch (alg)
            {
                case Algs.Aes:
                    return DecryptBlockCipher(new AesCryptoServiceProvider(), cipher =>
                    {
                        cipher.KeySize = keyBits;
                        return DeriveKey(password, salt, keyBits / 8);
                    }, ct, iv);
                case Algs.Des:
                    return DecryptBlockCipher(new DESCryptoServiceProvider(), cipher => DeriveKey(password, salt, 8), ct, iv);
                case Algs.TripleDes:
                    return DecryptBlockCipher(new TripleDESCryptoServiceProvider(), cipher => DeriveKey(password, salt, 24), ct, iv);
                case Algs.Rc4:
                    return Rc4Apply(ct, DeriveKey(password, salt, 16));
                case Algs.Xor:
                    return XorApply(ct, DeriveKey(password, salt, 16));
            }
            throw new ArgumentException("不支持的算法。");
        }

        private static byte[] EncryptBlockCipher(SymmetricAlgorithm cipher, Func<SymmetricAlgorithm, byte[]> keyFactory, byte[] plain, byte[] salt, CipherMode mode)
        {
            using (cipher)
            {
                cipher.Mode = mode;
                cipher.Padding = PaddingMode.PKCS7;
                cipher.Key = keyFactory(cipher);
                byte[] iv = null;
                if (mode != CipherMode.ECB)
                {
                    cipher.GenerateIV();
                    iv = cipher.IV;
                }
                using (ICryptoTransform enc = cipher.CreateEncryptor())
                {
                    return Pack(salt, iv, enc.TransformFinalBlock(plain, 0, plain.Length), mode);
                }
            }
        }

        private static byte[] DecryptBlockCipher(SymmetricAlgorithm cipher, Func<SymmetricAlgorithm, byte[]> keyFactory, byte[] ct, byte[] iv)
        {
            using (cipher)
            {
                cipher.Mode = iv == null ? CipherMode.ECB : CipherMode.CBC;
                cipher.Padding = PaddingMode.PKCS7;
                cipher.Key = keyFactory(cipher);
                if (iv != null) cipher.IV = iv;
                using (ICryptoTransform dec = cipher.CreateDecryptor())
                {
                    return dec.TransformFinalBlock(ct, 0, ct.Length);
                }
            }
        }

        // 封装格式：版本(1) | 标志(1) | salt(16) | [iv(16)] | 密文。
        // 标志位：0x01 = 携带 IV（CBC），0x02 = ECB 模式。
        public static byte[] Pack(byte[] salt, byte[] iv, byte[] ct, CipherMode mode)
        {
            byte flags = 0;
            if (iv != null) flags |= 0x01;
            if (mode == CipherMode.ECB) flags |= 0x02;
            using (MemoryStream ms = new MemoryStream())
            {
                ms.WriteByte(FormatVersion);
                ms.WriteByte(flags);
                ms.Write(salt, 0, salt.Length);
                if (iv != null) ms.Write(iv, 0, iv.Length);
                ms.Write(ct, 0, ct.Length);
                return ms.ToArray();
            }
        }

        public static void Unpack(byte[] payload, out byte[] salt, out byte[] iv, out byte[] ct)
        {
            if (payload == null || payload.Length < 2 + SaltSize)
                throw new FormatException("密文数据不完整，无法解析。");
            if (payload[0] != FormatVersion)
                throw new FormatException("不支持的密文格式版本：" + payload[0] + "。");
            byte flags = payload[1];
            int pos = 2;
            salt = new byte[SaltSize];
            Buffer.BlockCopy(payload, pos, salt, 0, SaltSize);
            pos += SaltSize;
            if ((flags & 0x01) != 0)
            {
                if (payload.Length - pos < IvSize) throw new FormatException("密文缺少 IV，数据可能已损坏。");
                iv = new byte[IvSize];
                Buffer.BlockCopy(payload, pos, iv, 0, IvSize);
                pos += IvSize;
            }
            else iv = null;
            ct = new byte[payload.Length - pos];
            Buffer.BlockCopy(payload, pos, ct, 0, ct.Length);
        }

        public static byte[] Rc4Apply(byte[] data, byte[] key)
        {
            byte[] s = new byte[256];
            for (int i = 0; i < 256; i++) s[i] = (byte)i;
            int j = 0;
            for (int i = 0; i < 256; i++)
            {
                j = (j + s[i] + key[i % key.Length]) & 0xFF;
                byte tmp = s[i]; s[i] = s[j]; s[j] = tmp;
            }
            byte[] output = new byte[data.Length];
            int a = 0, b = 0;
            for (int k = 0; k < data.Length; k++)
            {
                a = (a + 1) & 0xFF;
                b = (b + s[a]) & 0xFF;
                byte t = s[a]; s[a] = s[b]; s[b] = t;
                output[k] = (byte)(data[k] ^ s[(s[a] + s[b]) & 0xFF]);
            }
            return output;
        }

        public static byte[] XorApply(byte[] data, byte[] key)
        {
            byte[] output = new byte[data.Length];
            for (int i = 0; i < data.Length; i++) output[i] = (byte)(data[i] ^ key[i % key.Length]);
            return output;
        }
    }

    /// <summary>散列、HMAC 与 PBKDF2。</summary>
    public static class Digests
    {
        public static HashAlgorithm CreateHash(string alg)
        {
            switch ((alg ?? "").ToUpperInvariant())
            {
                case "MD5": return MD5.Create();
                case "SHA1": return SHA1.Create();
                case "SHA256": return SHA256.Create();
                case "SHA384": return SHA384.Create();
                case "SHA512": return SHA512.Create();
            }
            throw new ArgumentException("不支持的散列算法：" + alg);
        }

        public static string HashHex(string alg, byte[] data)
        {
            using (HashAlgorithm h = CreateHash(alg)) return Codec.ToHex(h.ComputeHash(data));
        }

        public static string HmacHex(string alg, byte[] data, string key)
        {
            byte[] k = Codec.Utf8(key ?? "");
            byte[] result;
            string upper = (alg ?? "").ToUpperInvariant();
            if (upper == "MD5")
            {
                using (HMACMD5 h = new HMACMD5(k)) result = h.ComputeHash(data);
            }
            else if (upper == "SHA1")
            {
                using (HMACSHA1 h = new HMACSHA1(k)) result = h.ComputeHash(data);
            }
            else if (upper == "SHA256")
            {
                using (HMACSHA256 h = new HMACSHA256(k)) result = h.ComputeHash(data);
            }
            else if (upper == "SHA512")
            {
                using (HMACSHA512 h = new HMACSHA512(k)) result = h.ComputeHash(data);
            }
            else throw new ArgumentException("不支持的 HMAC 算法：" + alg);
            return Codec.ToHex(result);
        }

        /// <summary>PBKDF2 要求盐至少 8 字节，短盐会先经 SHA-256 扩展。</summary>
        public static byte[] NormalizeSalt(byte[] salt)
        {
            if (salt == null || salt.Length == 0) return Codec.Utf8("CipherBox");
            if (salt.Length >= 8) return salt;
            using (SHA256 sha = SHA256.Create())
            {
                byte[] h = sha.ComputeHash(salt);
                byte[] buf = new byte[8];
                Buffer.BlockCopy(h, 0, buf, 0, 8);
                return buf;
            }
        }

        public static byte[] HmacBytes(string alg, byte[] data, string key)
        {
            string upper = (alg ?? "").ToUpperInvariant();
            byte[] k = Codec.Utf8(key ?? "");
            if (upper == "MD5") { using (HMACMD5 h = new HMACMD5(k)) return h.ComputeHash(data); }
            if (upper == "SHA1") { using (HMACSHA1 h = new HMACSHA1(k)) return h.ComputeHash(data); }
            if (upper == "SHA512") { using (HMACSHA512 h = new HMACSHA512(k)) return h.ComputeHash(data); }
            using (HMACSHA256 h2 = new HMACSHA256(k)) return h2.ComputeHash(data);
        }

        public static string Pbkdf2Hex(string password, string salt, int iterations, int length)
        {
            return Codec.ToHex(Pbkdf2(password, Codec.Utf8(salt ?? ""), iterations, length));
        }

        public static byte[] Pbkdf2(string password, byte[] salt, int iterations, int length)
        {
            using (Rfc2898DeriveBytes kdf = new Rfc2898DeriveBytes(password ?? "", NormalizeSalt(salt), Math.Max(1, iterations), HashAlgorithmName.SHA256))
            {
                return kdf.GetBytes(Math.Max(1, length));
            }
        }
    }

    /// <summary>摩斯电码、凯撒、维吉尼亚等古典密码。</summary>
    public static class Classic
    {
        // 字符|摩斯码，用竖线分隔，避免首位字符与码元混淆。
        private static readonly string[] MorseTable =
        {
            "A|.-", "B|-...", "C|-.-.", "D|-..", "E|.", "F|..-.", "G|--.", "H|....", "I|..", "J|.---",
            "K|-.-", "L|.-..", "M|--", "N|-.", "O|---", "P|.--.", "Q|--.-", "R|.-.", "S|...", "T|-",
            "U|..-", "V|...-", "W|.--", "X|-..-", "Y|-.--", "Z|--..",
            "0|-----", "1|.----", "2|..---", "3|...--", "4|....-", "5|.....", "6|-....", "7|--...", "8|---..", "9|----.",
            ".|.-.-.-", ",|--..--", "?|..--..", "!|-.-.--", "/|-..-.", "-|-....-", ":|---...", ";|-.-.-.", "'|.----.", "dq|.-..-."
        };

        private static Dictionary<char, string> BuildMorseMap()
        {
            Dictionary<char, string> map = new Dictionary<char, string>();
            foreach (string entry in MorseTable)
            {
                int i = entry.IndexOf('|');
                string left = entry.Substring(0, i);
                string code = entry.Substring(i + 1);
                char c;
                if (left == "dq") c = '"'; else c = left[0];
                map[c] = code;
            }
            return map;
        }

        public static string MorseEncode(string text)
        {
            Dictionary<char, string> map = BuildMorseMap();
            StringBuilder sb = new StringBuilder();
            string upper = (text ?? "").ToUpperInvariant();
            for (int i = 0; i < upper.Length; i++)
            {
                char c = upper[i];
                if (c == ' ')
                {
                    sb.Append(" / ");
                    continue;
                }
                string code;
                if (map.TryGetValue(c, out code))
                {
                    sb.Append(code);
                    sb.Append(' ');
                }
            }
            return sb.ToString().Trim();
        }

        public static string MorseDecode(string text)
        {
            Dictionary<string, char> reverse = new Dictionary<string, char>();
            foreach (string entry in MorseTable)
            {
                int i = entry.IndexOf('|');
                string left = entry.Substring(0, i);
                string code = entry.Substring(i + 1);
                char c;
                if (left == "dq") c = '"'; else c = left[0];
                reverse[code] = c;
            }
            string[] words = (text ?? "").Replace("\r", " ").Replace("\n", " ").Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            StringBuilder sb = new StringBuilder();
            foreach (string word in words)
            {
                if (sb.Length > 0) sb.Append(' ');
                string[] parts = word.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string p in parts)
                {
                    char c;
                    if (reverse.TryGetValue(p, out c)) sb.Append(c);
                    else sb.Append('?');
                }
            }
            return sb.ToString();
        }

        public static string Caesar(string text, int shift)
        {
            StringBuilder sb = new StringBuilder(text.Length);
            foreach (char c in text)
            {
                if (c >= 'a' && c <= 'z') sb.Append((char)('a' + ((c - 'a' + shift) % 26 + 26) % 26));
                else if (c >= 'A' && c <= 'Z') sb.Append((char)('A' + ((c - 'A' + shift) % 26 + 26) % 26));
                else sb.Append(c);
            }
            return sb.ToString();
        }

        public static string Rot13(string text)
        {
            return Caesar(text, 13);
        }

        public static string Atbash(string text)
        {
            StringBuilder sb = new StringBuilder(text.Length);
            foreach (char c in text)
            {
                if (c >= 'a' && c <= 'z') sb.Append((char)('z' - (c - 'a')));
                else if (c >= 'A' && c <= 'Z') sb.Append((char)('Z' - (c - 'A')));
                else if (c >= '0' && c <= '9') sb.Append((char)('9' - (c - '0')));
                else sb.Append(c);
            }
            return sb.ToString();
        }

        public static string Vigenere(string text, string key, bool decrypt)
        {
            string k = (key ?? "").ToUpperInvariant();
            StringBuilder sb = new StringBuilder(text.Length);
            int ki = 0;
            foreach (char c in text)
            {
                char letter;
                int shift;
                if (k.Length == 0) return "密钥不能为空。";
                shift = k[ki % k.Length] - 'A';
                if (decrypt) shift = -shift;
                if (c >= 'a' && c <= 'z')
                {
                    letter = (char)('a' + ((c - 'a' + shift) % 26 + 26) % 26);
                    ki++;
                }
                else if (c >= 'A' && c <= 'Z')
                {
                    letter = (char)('A' + ((c - 'A' + shift) % 26 + 26) % 26);
                    ki++;
                }
                else letter = c;
                sb.Append(letter);
            }
            return sb.ToString();
        }
    }
}
