using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CipherBox.Core
{
    /// <summary>常见弱口令库（内置约 260 条，可继续追加文件）。</summary>
    public static class CommonPasswords
    {
        public static readonly string[] BuiltIn =
        {
            "123456", "password", "123456789", "12345678", "12345", "qwerty", "1234567", "111111", "123123", "1234567890",
            "admin", "1234", "000000", "1q2w3e4r", "654321", "666666", "123321", "abc123", "888888", "password1",
            "qwerty123", "1qaz2wsx", "123qwe", "zxcvbnm", "121212", "555555", "1q2w3e", "123456a", "dragon", "monkey",
            "letmein", "iloveyou", "trustno1", "sunshine", "master", "welcome", "shadow", "superman", "michael", "football",
            "baseball", "whatever", "princess", "starwars", "computer", "qazwsx", "123abc", "1qazxsw2", "112233", "159753",
            "qwertyuiop", "asdfghjkl", "1q2w3e4r5t", "1qaz2wsx3edc", "a123456", "aa123456", "abc123456", "p@ssw0rd", "passw0rd", "admin123",
            "root", "toor", "test", "guest", "user", "88888888", "66666666", "11111111", "000000000", "12341234",
            "5201314", "1314520", "7758521", "woaini1314", "woaini", "woshishui", "buzhidao", "147258369", "741852963", "963852741",
            "asdfghjkl;", "qwertyui", "zxcvbnm,", "1q2w3e4r5t6y", "q1w2e3r4", "1qaz@wsx", "qwe123", "asd123", "zxc123", "123qweasd",
            "iloveyou1", "sweetheart", "babygirl", "baby", "honey", "lovely", "angel", "flower", "summer", "winter",
            "spring", "autumn", "january", "february", "march", "april", "june", "july", "august", "september",
            "october", "november", "december", "monday", "friday", "sunday", "freedom", "hello", "hello123", "helloworld",
            "changeme", "default", "secret", "pass", "password123", "password!", "pass1234", "adminadmin", "administrator", "administrator1",
            "system", "manager", "office", "school", "college", "student", "teacher", "family", "friends", "forever",
            "internet", "online", "windows", "linux", "android", "iphone", "samsung", "huawei", "xiaomi", "google",
            "microsoft", "apple", "oracle", "mysql", "postgres", "sa123456", "sa", "sqlserver", "database", "backup",
            "test123", "test1234", "guest123", "demo123", "temp123", "welcome1", "welcome123", "qwerty12", "qwerty1234", "zaq12wsx",
            "zaq1zaq1", "xsw21qaz", "1q2w3e4r!", "qazwsxedc", "qazwsx123", "asdf1234", "asdfgh", "zxcvbn", "qwer1234", "qweasdzxc",
            "123456789a", "a123456789", "1a2b3c4d", "a1b2c3d4", "abc12345", "abcd1234", "abcdefgh", "aaaaaa", "aaaa1111", "aa123123",
            "0000000", "1111111", "222222", "333333", "444444", "777777", "8888888", "999999", "159357", "147258",
            "2580", "147258369a", "123654", "456789", "987654321", "987654", "123123123", "321321", "11223344", "1234554321",
            "520520", "5211314", "1314", "1314521", "woaini520", "5201314520", "iloveyou520", "tianya", "baidu", "taobao",
            "qq123456", "qq123456789", "wechat123", "wx123456", "alipay123", "123456qq", "123456789qq", "abc123!", "admin!123", "admin@123",
            "root123", "root@123", "p@ssword", "p@ssw0rd123", "Passw0rd!", "Password1", "Qwerty123", "Qwerty!23", "Abc123456", "Admin123!",
            "letmein123", "iloveyou!", "sunshine1", "princess1", "football1", "baseball1", "superman1", "starwars1", "trustno1!", "master123",
            "fuckyou", "fuckyou1", "asshole", "biteme", "buster", "soccer", "hockey", "killer", "matrix", "pokemon",
            "naruto", "sasuke", "onepiece", "minecraft", "fortnite", "chelsea", "arsenal", "liverpool", "barcelona", "realmadrid",
            "jordan", "kobe", "lebron", "messi", "ronaldo", "yankees", "cowboys", "steelers", "packers", "eagles",
            "1q2w3e4r5t6y7u", "1qaz2wsx3edc4rfv", "1qazxsw23edcvfr4", "qweasdzxc123", "asdfghjkl123", "zxcvbnm123", "1234567890123456", "12345678901234567890", "qwertyuiop123", "1q2w3e4r5t6y7u8i",
            "superadmin", "webmaster", "sysadmin", "operator", "support", "service", "public", "private", "company", "finance",
            "hr123456", "it123456", "dev123456", "prod123456", "ops123456", "vpn123456", "wifi123456", "router", "router123", "cisco",
            "netgear", "tplink", "dlink", "12345678910", "0123456789", "abcdef", "abcdefg", "abcdefghij", "abcabc", "123abc123",
            "asdf", "asdfasdf", "qwer", "qwerqwer", "zxcv", "zxcvzxcv", "qwertyqwerty", "passwordpassword", "admin888", "admin666"
        };
    }

    public class StrengthResult
    {
        public int Score;
        public string Label;
        public double Entropy;
        public List<string> Tips = new List<string>();
        public bool IsCommon;
        public string CommonHit;
    }

    /// <summary>弱口令检测、强度评估、随机口令生成、哈希反查。</summary>
    public static class PasswordTools
    {
        private static readonly List<string> extra = new List<string>();
        private static Dictionary<string, string> index;

        public static List<string> All()
        {
            List<string> list = new List<string>(CommonPasswords.BuiltIn);
            list.AddRange(extra);
            return list;
        }

        public static int Count { get { return CommonPasswords.BuiltIn.Length + extra.Count; } }

        public static void AddFromFile(string path)
        {
            foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
            {
                string s = line.Trim();
                if (s.Length == 0 || s.StartsWith("#")) continue;
                if (!extra.Contains(s)) extra.Add(s);
            }
            index = null;
        }

        private static Dictionary<string, string> GetIndex()
        {
            if (index == null)
            {
                index = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string p in All())
                {
                    if (!index.ContainsKey(p)) index[p] = p;
                }
            }
            return index;
        }

        /// <summary>判断是否为内置常见弱口令（忽略大小写）。</summary>
        public static string FindCommon(string password)
        {
            if (string.IsNullOrEmpty(password)) return null;
            string hit;
            if (GetIndex().TryGetValue(password, out hit)) return hit;
            string lower = password.ToLowerInvariant();
            if (GetIndex().TryGetValue(lower, out hit)) return hit;
            return null;
        }

        private static int CharsetSize(string pw)
        {
            bool lower = false, upper = false, digit = false, symbol = false, other = false;
            foreach (char c in pw)
            {
                if (c >= 'a' && c <= 'z') lower = true;
                else if (c >= 'A' && c <= 'Z') upper = true;
                else if (c >= '0' && c <= '9') digit = true;
                else if (c < 128) symbol = true;
                else other = true;
            }
            int size = 0;
            if (lower) size += 26;
            if (upper) size += 26;
            if (digit) size += 10;
            if (symbol) size += 33;
            if (other) size += 4000;
            return Math.Max(1, size);
        }

        public static StrengthResult Evaluate(string password)
        {
            StrengthResult r = new StrengthResult();
            string pw = password ?? "";
            if (pw.Length == 0)
            {
                r.Score = 0;
                r.Label = "空";
                r.Tips.Add("请输入要检测的口令。");
                return r;
            }

            r.CommonHit = FindCommon(pw);
            r.IsCommon = r.CommonHit != null;

            int charset = CharsetSize(pw);
            r.Entropy = pw.Length * Math.Log(charset, 2);

            int score = (int)Math.Min(100, Math.Round(r.Entropy * 0.95));

            if (pw.Length < 8) r.Tips.Add("长度不足 8 位，建议至少 12 位。");
            else if (pw.Length < 12) r.Tips.Add("长度尚可，建议提升到 12 位以上。");

            bool hasLower = false, hasUpper = false, hasDigit = false, hasSymbol = false;
            foreach (char c in pw)
            {
                if (c >= 'a' && c <= 'z') hasLower = true;
                else if (c >= 'A' && c <= 'Z') hasUpper = true;
                else if (c >= '0' && c <= '9') hasDigit = true;
                else hasSymbol = true;
            }
            if (!hasUpper) r.Tips.Add("缺少大写字母。");
            if (!hasLower) r.Tips.Add("缺少小写字母。");
            if (!hasDigit) r.Tips.Add("缺少数字。");
            if (!hasSymbol) r.Tips.Add("缺少特殊符号。");

            if (r.IsCommon)
            {
                score = Math.Min(score, 8);
                r.Tips.Insert(0, "该口令命中常见弱口令库（" + r.CommonHit + "），极易被彩虹表/字典攻击破解。");
            }

            if (HasRepeatedRun(pw, 3))
            {
                score -= 15;
                r.Tips.Add("存在连续重复字符（如 aaa、111）。");
            }
            if (IsSequential(pw))
            {
                score -= 15;
                r.Tips.Add("包含键盘或数字顺序序列（如 1234、qwerty）。");
            }
            if (pw.Length >= 4 && (pw.ToLowerInvariant() == pw.ToUpperInvariant()))
            {
                score -= 10;
            }
            if (System.Text.RegularExpressions.Regex.IsMatch(pw, "^[a-zA-Z]+$") || System.Text.RegularExpressions.Regex.IsMatch(pw, "^[0-9]+$"))
            {
                score -= 10;
                r.Tips.Add("仅使用单一字符类型。");
            }

            score = Math.Max(0, Math.Min(100, score));
            r.Score = score;
            if (score < 20) r.Label = "极弱";
            else if (score < 40) r.Label = "弱";
            else if (score < 60) r.Label = "一般";
            else if (score < 80) r.Label = "较强";
            else r.Label = "强";
            if (r.Tips.Count == 0) r.Tips.Add("长度与字符组合良好，记得不同站点使用不同口令。");
            return r;
        }

        private static bool HasRepeatedRun(string s, int run)
        {
            int count = 1;
            for (int i = 1; i < s.Length; i++)
            {
                if (s[i] == s[i - 1]) { count++; if (count >= run) return true; }
                else count = 1;
            }
            return false;
        }

        private static bool IsSequential(string s)
        {
            string lower = s.ToLowerInvariant();
            string[] patterns = { "0123456789", "9876543210", "abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba", "qwertyuiop", "asdfghjkl", "zxcvbnm", "qazwsx", "123qwe" };
            foreach (string p in patterns)
            {
                for (int i = 0; i + 4 <= p.Length; i++)
                {
                    string seg = p.Substring(i, 4);
                    if (lower.Contains(seg)) return true;
                }
            }
            return false;
        }

        public static string Generate(int length, bool upper, bool lower, bool digit, bool symbol, bool avoidAmbiguous)
        {
            const string U = "ABCDEFGHJKLMNPQRSTUVWXYZ";
            const string L = "abcdefghijkmnopqrstuvwxyz";
            const string D = "23456789";
            const string S = "!@#$%^&*-_=+?";
            const string U2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string L2 = "abcdefghijklmnopqrstuvwxyz";
            const string D2 = "0123456789";
            const string S2 = "!@#$%^&*()-_=+[]{};:,.<>?";

            string up = avoidAmbiguous ? U : U2;
            string lo = avoidAmbiguous ? L : L2;
            string di = avoidAmbiguous ? D : D2;
            string sy = avoidAmbiguous ? S : S2;

            StringBuilder pool = new StringBuilder();
            if (upper) pool.Append(up);
            if (lower) pool.Append(lo);
            if (digit) pool.Append(di);
            if (symbol) pool.Append(sy);
            if (pool.Length == 0) pool.Append(lo);

            StringBuilder sb = new StringBuilder();
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] buf = new byte[4];
                // 先保证每类至少一个字符。
                if (upper) sb.Append(Pick(up, rng));
                if (lower) sb.Append(Pick(lo, rng));
                if (digit) sb.Append(Pick(di, rng));
                if (symbol) sb.Append(Pick(sy, rng));
                while (sb.Length < length)
                {
                    rng.GetBytes(buf);
                    int v = BitConverter.ToInt32(buf, 0) & 0x7FFFFFFF;
                    sb.Append(pool[v % pool.Length]);
                }
                // 洗牌
                for (int i = sb.Length - 1; i > 0; i--)
                {
                    rng.GetBytes(buf);
                    int j = (BitConverter.ToInt32(buf, 0) & 0x7FFFFFFF) % (i + 1);
                    char t = sb[i]; sb[i] = sb[j]; sb[j] = t;
                }
            }
            return sb.ToString(0, length);
        }

        private static char Pick(string pool, RNGCryptoServiceProvider rng)
        {
            byte[] buf = new byte[4];
            rng.GetBytes(buf);
            int v = BitConverter.ToInt32(buf, 0) & 0x7FFFFFFF;
            return pool[v % pool.Length];
        }

        /// <summary>根据十六进制长度识别散列算法。</summary>
        public static string DetectHashAlg(string hash)
        {
            string h = (hash ?? "").Trim();
            foreach (char c in h)
            {
                if (!Uri.IsHexDigit(c)) return null;
            }
            switch (h.Length)
            {
                case 32: return "MD5";
                case 40: return "SHA1";
                case 64: return "SHA256";
                case 96: return "SHA384";
                case 128: return "SHA512";
            }
            return null;
        }

        /// <summary>在内置弱口令库中反查散列对应的明文。</summary>
        public static string LookupHash(string hash, out string alg, out int tried)
        {
            alg = DetectHashAlg(hash);
            tried = 0;
            if (alg == null) return null;
            string target = hash.Trim().ToLowerInvariant();
            foreach (string pw in All())
            {
                tried++;
                if (Digests.HashHex(alg, Codec.Utf8(pw)) == target) return pw;
            }
            return null;
        }
    }
}
