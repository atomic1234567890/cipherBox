using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CipherBox.Core
{
    /// <summary>文件流式加解密（AES-256-CBC + PBKDF2 派生口令密钥）。</summary>
    public static class FileCrypto
    {
        private static readonly byte[] Magic = new byte[] { (byte)'C', (byte)'B', (byte)'X', (byte)'1' };

        public static void Encrypt(string inputPath, string outputPath, string password, Action<double> progress)
        {
            if (!File.Exists(inputPath)) throw new FileNotFoundException("找不到待加密文件。", inputPath);
            byte[] salt = Codec.RandomBytes(16);
            byte[] key = Symmetric.DeriveKey(password, salt, 32);
            long total = new FileInfo(inputPath).Length;
            using (Aes aes = Aes.Create())
            {
                aes.KeySize = 256;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.Key = key;
                aes.GenerateIV();
                using (FileStream fin = new FileStream(inputPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (FileStream fout = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    fout.Write(Magic, 0, Magic.Length);
                    fout.Write(salt, 0, salt.Length);
                    fout.Write(aes.IV, 0, aes.IV.Length);
                    using (CryptoStream cs = new CryptoStream(fout, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        CopyWithProgress(fin, cs, total, progress);
                        cs.FlushFinalBlock();
                    }
                }
            }
        }

        public static void Decrypt(string inputPath, string outputPath, string password, Action<double> progress)
        {
            if (!File.Exists(inputPath)) throw new FileNotFoundException("找不到待解密文件。", inputPath);
            using (FileStream fin = new FileStream(inputPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (FileStream fout = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                byte[] head = new byte[36];
                if (fin.Length < 36 + 16) throw new FormatException("文件不是有效的 CipherBox 密文（长度不足）。");
                ReadExactly(fin, head, 0, head.Length);
                for (int i = 0; i < 4; i++)
                {
                    if (head[i] != Magic[i]) throw new FormatException("文件头不匹配，这不是 CipherBox 加密的文件。");
                }
                byte[] salt = new byte[16];
                byte[] iv = new byte[16];
                Buffer.BlockCopy(head, 4, salt, 0, 16);
                Buffer.BlockCopy(head, 20, iv, 0, 16);
                byte[] key = Symmetric.DeriveKey(password, salt, 32);
                long total = fin.Length - head.Length;
                using (Aes aes = Aes.Create())
                {
                    aes.KeySize = 256;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    aes.Key = key;
                    aes.IV = iv;
                    using (CryptoStream cs = new CryptoStream(fin, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        CopyWithProgress(cs, fout, total, progress);
                    }
                }
            }
        }

        private static void CopyWithProgress(Stream src, Stream dst, long total, Action<double> progress)
        {
            byte[] buffer = new byte[81920];
            long done = 0;
            int read;
            while ((read = src.Read(buffer, 0, buffer.Length)) > 0)
            {
                dst.Write(buffer, 0, read);
                done += read;
                if (progress != null && total > 0) progress(Math.Min(1.0, (double)done / total));
            }
            if (progress != null) progress(1.0);
        }

        private static void ReadExactly(Stream s, byte[] buffer, int offset, int count)
        {
            int read = 0;
            while (read < count)
            {
                int n = s.Read(buffer, offset + read, count - read);
                if (n <= 0) throw new EndOfStreamException("文件意外结束。");
                read += n;
            }
        }
    }
}
