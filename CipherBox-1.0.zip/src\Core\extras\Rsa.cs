using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CipherBox.Core
{
    /// <summary>极简 DER（ASN.1）编解码，用于 RSA 的 PEM 私钥/公钥导入导出。</summary>
    internal static class Der
    {
        public static byte[] Tlv(byte tag, byte[] content)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                ms.WriteByte(tag);
                int len = content.Length;
                if (len < 0x80) ms.WriteByte((byte)len);
                else if (len <= 0xFF)
                {
                    ms.WriteByte(0x81);
                    ms.WriteByte((byte)len);
                }
                else if (len <= 0xFFFF)
                {
                    ms.WriteByte(0x82);
                    ms.WriteByte((byte)(len >> 8));
                    ms.WriteByte((byte)(len & 0xFF));
                }
                else
                {
                    ms.WriteByte(0x83);
                    ms.WriteByte((byte)(len >> 16));
                    ms.WriteByte((byte)(len >> 8));
                    ms.WriteByte((byte)(len & 0xFF));
                }
                ms.Write(content, 0, content.Length);
                return ms.ToArray();
            }
        }

        public static byte[] Concat(params byte[][] parts)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                foreach (byte[] p in parts) ms.Write(p, 0, p.Length);
                return ms.ToArray();
            }
        }

        public static byte[] Seq(params byte[][] parts)
        {
            return Tlv(0x30, Concat(parts));
        }

        public static byte[] Integer(byte[] unsignedBigEndian)
        {
            int start = 0;
            while (start < unsignedBigEndian.Length - 1 && unsignedBigEndian[start] == 0) start++;
            int len = unsignedBigEndian.Length - start;
            bool pad = (unsignedBigEndian[start] & 0x80) != 0;
            byte[] content = new byte[len + (pad ? 1 : 0)];
            Buffer.BlockCopy(unsignedBigEndian, start, content, pad ? 1 : 0, len);
            return Tlv(0x02, content);
        }

        public static byte[] IntegerInt(int value)
        {
            return Integer(new byte[] { (byte)((value >> 24) & 0xFF), (byte)((value >> 16) & 0xFF), (byte)((value >> 8) & 0xFF), (byte)(value & 0xFF) });
        }

        public static byte[] OctetString(byte[] data)
        {
            return Tlv(0x04, data);
        }

        public static byte[] BitString(byte[] data)
        {
            byte[] content = new byte[data.Length + 1];
            Buffer.BlockCopy(data, 0, content, 1, data.Length);
            return Tlv(0x03, content);
        }

        public static byte[] Null()
        {
            return new byte[] { 0x05, 0x00 };
        }

        public static byte[] Oid(string dotted)
        {
            string[] parts = dotted.Split('.');
            byte[] first = new byte[] { (byte)(int.Parse(parts[0]) * 40 + int.Parse(parts[1])) };
            MemoryStream ms = new MemoryStream();
            ms.Write(first, 0, 1);
            for (int i = 2; i < parts.Length; i++)
            {
                long v = long.Parse(parts[i]);
                byte[] tmp = new byte[8];
                int n = 0;
                do
                {
                    tmp[n++] = (byte)(v & 0x7F);
                    v >>= 7;
                } while (v > 0);
                for (int j = n - 1; j >= 0; j--) ms.WriteByte((byte)(tmp[j] | (j > 0 ? 0x80 : 0)));
            }
            return Tlv(0x06, ms.ToArray());
        }
    }

    internal class DerNode
    {
        public byte Tag;
        public byte[] Content;
        public int ContentOffset;
        public int HeaderLength;

        public DerNode[] Children()
        {
            System.Collections.Generic.List<DerNode> list = new System.Collections.Generic.List<DerNode>();
            int pos = 0;
            while (pos < Content.Length)
            {
                DerNode node = Read(Content, pos);
                list.Add(node);
                pos += node.HeaderLength + node.Content.Length;
            }
            return list.ToArray();
        }

        public static DerNode Read(byte[] data, int offset)
        {
            if (data == null || offset + 2 > data.Length) throw new FormatException("DER 数据长度不足。");
            DerNode node = new DerNode();
            node.Tag = data[offset];
            int p = offset + 1;
            int len = data[p++];
            if ((len & 0x80) != 0)
            {
                int count = len & 0x7F;
                if (count < 1 || count > 3) throw new FormatException("非法的 DER 长度字段。");
                len = 0;
                for (int i = 0; i < count; i++) len = (len << 8) | data[p++];
            }
            if (offset + (p - offset) + len > data.Length) throw new FormatException("DER 数据被截断。");
            node.ContentOffset = p;
            node.HeaderLength = p - offset;
            node.Content = new byte[len];
            Buffer.BlockCopy(data, p, node.Content, 0, len);
            return node;
        }

        public static DerNode FromBytes(byte[] data)
        {
            return Read(data, 0);
        }
    }

    public static class RsaTool
    {
        private const string OidRsaEncryption = "1.2.840.113549.1.1.1";

        public static RSA Generate(int bits)
        {
            RSA rsa = RSA.Create();
            rsa.KeySize = bits;
            return rsa;
        }

        public static string ToPemPrivate(RSA rsa)
        {
            RSAParameters p = rsa.ExportParameters(true);
            byte[] pkcs1 = Der.Seq(
                Der.IntegerInt(0),
                Der.Integer(p.Modulus),
                Der.Integer(p.Exponent),
                Der.Integer(p.D),
                Der.Integer(p.P),
                Der.Integer(p.Q),
                Der.Integer(p.DP),
                Der.Integer(p.DQ),
                Der.Integer(p.InverseQ));
            byte[] pkcs8 = Der.Seq(
                Der.IntegerInt(0),
                Der.Seq(Der.Oid(OidRsaEncryption), Der.Null()),
                Der.OctetString(pkcs1));
            return WrapPem("PRIVATE KEY", pkcs8);
        }

        public static string ToPemPublic(RSA rsa)
        {
            RSAParameters p = rsa.ExportParameters(false);
            byte[] rsaPub = Der.Seq(Der.Integer(p.Modulus), Der.Integer(p.Exponent));
            byte[] spki = Der.Seq(
                Der.Seq(Der.Oid(OidRsaEncryption), Der.Null()),
                Der.BitString(rsaPub));
            return WrapPem("PUBLIC KEY", spki);
        }

        private static string WrapPem(string label, byte[] der)
        {
            string b64 = Convert.ToBase64String(der);
            StringBuilder sb = new StringBuilder();
            sb.Append("-----BEGIN ").Append(label).Append("-----\r\n");
            for (int i = 0; i < b64.Length; i += 64)
            {
                sb.Append(b64.Substring(i, Math.Min(64, b64.Length - i))).Append("\r\n");
            }
            sb.Append("-----END ").Append(label).Append("-----");
            return sb.ToString();
        }

        private static byte[] UnwrapPem(string pem)
        {
            if (string.IsNullOrEmpty(pem)) throw new FormatException("PEM 内容为空。");
            int header = pem.IndexOf("-----BEGIN", StringComparison.Ordinal);
            if (header < 0) throw new FormatException("未找到 PEM 头（-----BEGIN ...-----）。");
            int bodyStart = pem.IndexOf('\n', header);
            if (bodyStart < 0) throw new FormatException("PEM 头格式不正确。");
            int footer = pem.IndexOf("-----END", bodyStart, StringComparison.Ordinal);
            string body = footer < 0 ? pem.Substring(bodyStart + 1) : pem.Substring(bodyStart + 1, footer - bodyStart - 1);
            StringBuilder sb = new StringBuilder();
            foreach (char c in body)
            {
                if (!char.IsWhiteSpace(c)) sb.Append(c);
            }
            return Convert.FromBase64String(sb.ToString());
        }

        private static RSAParameters ParsePkcs1(byte[] der)
        {
            DerNode node = DerNode.FromBytes(der);
            DerNode[] parts = node.Children();
            if (parts.Length < 9) throw new FormatException("PKCS#1 私钥结构不正确。");
            RSAParameters p = new RSAParameters();
            p.Modulus = parts[1].Content;
            p.Exponent = parts[2].Content;
            p.D = parts[3].Content;
            p.P = parts[4].Content;
            p.Q = parts[5].Content;
            p.DP = parts[6].Content;
            p.DQ = parts[7].Content;
            p.InverseQ = parts[8].Content;
            return p;
        }

        public static RSA FromPemPrivate(string pem)
        {
            byte[] der = UnwrapPem(pem);
            RSAParameters p;
            DerNode node = DerNode.FromBytes(der);
            DerNode[] outer = node.Children();
            bool isPkcs8 = outer.Length >= 3 && outer[1].Tag == 0x30 && outer[1].Content.Length > 0 && outer[1].Content[0] == 0x06;
            if (isPkcs8)
            {
                DerNode[] alg = outer[1].Children();
                if (!OidMatches(alg[0], OidRsaEncryption)) throw new FormatException("该私钥不是 RSA 密钥。");
                p = ParsePkcs1(outer[2].Content);
            }
            else
            {
                p = ParsePkcs1(der);
            }
            RSA rsa = RSA.Create();
            rsa.ImportParameters(p);
            return rsa;
        }

        public static RSA FromPemPublic(string pem)
        {
            byte[] der = UnwrapPem(pem);
            DerNode node = DerNode.FromBytes(der);
            DerNode[] outer = node.Children();
            RSAParameters p = new RSAParameters();
            if (outer.Length >= 2 && outer[1].Tag == 0x03)
            {
                // SubjectPublicKeyInfo
                byte[] bitContent = outer[1].Content;
                byte[] inner = new byte[bitContent.Length - 1];
                Buffer.BlockCopy(bitContent, 1, inner, 0, inner.Length);
                DerNode rsaPub = DerNode.FromBytes(inner);
                DerNode[] parts = rsaPub.Children();
                p.Modulus = parts[0].Content;
                p.Exponent = parts[1].Content;
            }
            else if (outer.Length >= 2 && outer[0].Tag == 0x02)
            {
                // PKCS#1 RSAPublicKey
                p.Modulus = outer[0].Content;
                p.Exponent = outer[1].Content;
            }
            else throw new FormatException("公钥格式无法识别。");
            RSA rsa = RSA.Create();
            rsa.ImportParameters(p);
            return rsa;
        }

        private static bool OidMatches(DerNode node, string dotted)
        {
            return node.Tag == 0x06 && node.Content.Length > 2 && node.Content[0] == 0x2A && node.Content[1] == 0x86;
        }

        public static byte[] EncryptBytes(byte[] data, RSA rsa)
        {
            return rsa.Encrypt(data, RSAEncryptionPadding.Pkcs1);
        }

        public static byte[] DecryptBytes(byte[] data, RSA rsa)
        {
            return rsa.Decrypt(data, RSAEncryptionPadding.Pkcs1);
        }

        public static string SignBase64(string text, RSA rsa, string hashAlg)
        {
            byte[] data = Codec.Utf8(text ?? "");
            byte[] sig;
            switch ((hashAlg ?? "SHA256").ToUpperInvariant())
            {
                case "MD5": sig = rsa.SignData(data, HashAlgorithmName.MD5, RSASignaturePadding.Pkcs1); break;
                case "SHA1": sig = rsa.SignData(data, HashAlgorithmName.SHA1, RSASignaturePadding.Pkcs1); break;
                case "SHA512": sig = rsa.SignData(data, HashAlgorithmName.SHA512, RSASignaturePadding.Pkcs1); break;
                default: sig = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1); break;
            }
            return Convert.ToBase64String(sig);
        }

        public static bool VerifyBase64(string text, string signatureB64, RSA rsa, string hashAlg)
        {
            byte[] data = Codec.Utf8(text ?? "");
            byte[] sig = Convert.FromBase64String(signatureB64 ?? "");
            switch ((hashAlg ?? "SHA256").ToUpperInvariant())
            {
                case "MD5": return rsa.VerifyData(data, sig, HashAlgorithmName.MD5, RSASignaturePadding.Pkcs1);
                case "SHA1": return rsa.VerifyData(data, sig, HashAlgorithmName.SHA1, RSASignaturePadding.Pkcs1);
                case "SHA512": return rsa.VerifyData(data, sig, HashAlgorithmName.SHA512, RSASignaturePadding.Pkcs1);
                default: return rsa.VerifyData(data, sig, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }

        public static int KeyBits(RSA rsa)
        {
            try { return rsa.KeySize; }
            catch (Exception) { return 0; }
        }
    }
}
