using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using CipherBox.Core;

namespace CipherBox.SelfTest
{
    public static class Program
    {
        private static int passed;
        private static int failed;
        private static readonly List<string> failures = new List<string>();

        public static int Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("CipherBox 核心自检开始 ...");
            Console.WriteLine();

#if !SKIP_TESTCODECS
            TestCodecs();
#endif
#if !SKIP_TESTHASHES
            TestHashes();
#endif
#if !SKIP_TESTSYMMETRIC
            TestSymmetric();
#endif
#if !SKIP_TESTCLASSIC
            TestClassic();
#endif
#if !SKIP_TESTRSA
            TestRsa();
#endif
#if !SKIP_TESTPASSWORDTOOLS
            TestPasswordTools();
#endif
#if !SKIP_TESTFILECRYPTO
            TestFileCrypto();
#endif

            Console.WriteLine();
            Console.WriteLine("----- 结果 -----");
            Console.WriteLine("通过: " + passed + "   失败: " + failed);
            foreach (string f in failures) Console.WriteLine("  [FAIL] " + f);
            if (failed == 0) Console.WriteLine("全部通过 ✔");
            return failed == 0 ? 0 : 1;
        }

        private static void Check(string name, bool ok, string detail)
        {
            if (ok)
            {
                passed++;
                Console.WriteLine("  PASS  " + name);
            }
            else
            {
                failed++;
                failures.Add(name + " -> " + detail);
                Console.WriteLine("  FAIL  " + name + "  (" + detail + ")");
            }
        }

        private static void Eq(string name, string expected, string actual)
        {
            Check(name, expected == actual, "期望 [" + Codec.Truncate(expected, 60) + "] 实际 [" + Codec.Truncate(actual, 60) + "]");
        }

        private static void TestCodecs()
        {
            Console.WriteLine("[编码]");
            Eq("Hex 往返", "48656c6c6f", Codec.ToHex(Codec.Utf8("Hello")));
            Eq("Hex 解码", "Hello", Codec.Utf8(Codec.FromHex("48656C6C6F")));
            Eq("Base64", "SGVsbG8gQ2lwaGVyQm94", Convert.ToBase64String(Codec.Utf8("Hello CipherBox")));
            Eq("Base32", "JBSWY3DPEBLW64TMMQ", Codec.ToBase32(Codec.Utf8("Hello World")));
            Eq("Base32 往返", "Hello World", Codec.Utf8(Codec.FromBase32(Codec.ToBase32(Codec.Utf8("Hello World")))));
            Eq("Base64Url", "aGVsbG8", Codec.ToBase64Url(Codec.Utf8("hello")));
            Eq("Base64Url 往返", "中文测试", Codec.Utf8(Codec.FromBase64Url(Codec.ToBase64Url(Codec.Utf8("中文测试")))));
            Eq("位串往返", "01000001", Codec.ToBits(new byte[] { 65 }));
            Eq("位串解码", "A", Codec.Utf8(Codec.FromBits("01000001")));
        }

        private static void TestHashes()
        {
            Console.WriteLine("[散列]");
            Eq("MD5(abc)", "900150983cd24fb0d6963f7d28e17f72", Digests.HashHex("MD5", Codec.Utf8("abc")));
            Eq("SHA1(abc)", "a9993e364706816aba3e25717850c26c9cd0d89d", Digests.HashHex("SHA1", Codec.Utf8("abc")));
            Eq("SHA256(abc)", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Digests.HashHex("SHA256", Codec.Utf8("abc")));
            Eq("SHA512(abc)", "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f", Digests.HashHex("SHA512", Codec.Utf8("abc")));
            Eq("HMAC-SHA256", "f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8", Digests.HmacHex("SHA256", Codec.Utf8("The quick brown fox jumps over the lazy dog"), "key"));
            Eq("PBKDF2-SHA256 x1", "037b719375a1bb4a4edd85376cb8b3e57f33a08bf69c0264248824f712e1509f", Digests.Pbkdf2Hex("password", "salt1234", 1, 32));
            Eq("PBKDF2-SHA256 x10000", "cb14e1e1f7ac2fe57f2fcaa462d4ad903867450d9778d2ccf939d8ad3cb99982", Digests.Pbkdf2Hex("password", "salt1234", 10000, 32));
            Eq("PBKDF2 短盐不报错", "64", Digests.Pbkdf2Hex("p", "ab", 2, 32).Length.ToString());
        }

        private static void TestSymmetric()
        {
            Console.WriteLine("[对称加密]");
            string[] samples = { "", "hello", "Hello, CipherBox 中文测试 🚀", new string('A', 5000) };
            int[] keyBits = { 128, 192, 256 };
            foreach (int bits in keyBits)
            {
                foreach (CipherMode mode in new CipherMode[] { CipherMode.CBC, CipherMode.ECB })
                {
                    foreach (string s in samples)
                    {
                        byte[] enc = Symmetric.Encrypt(Codec.Utf8(s), "P@ssw0rd-测试", Algs.Aes, bits, mode);
                        byte[] dec = Symmetric.Decrypt(enc, "P@ssw0rd-测试", Algs.Aes, bits);
                        Check("AES-" + bits + "-" + mode + " 往返(长度 " + s.Length + ")", Codec.Utf8(dec) == s, "解密结果不一致");
                    }
                    // 随机盐：同一明文两次加密结果应不同
                    byte[] e1 = Symmetric.Encrypt(Codec.Utf8("same"), "k", Algs.Aes, bits, mode);
                    byte[] e2 = Symmetric.Encrypt(Codec.Utf8("same"), "k", Algs.Aes, bits, mode);
                    Check("AES-" + bits + "-" + mode + " 随机盐", Convert.ToBase64String(e1) != Convert.ToBase64String(e2), "两次密文相同");
                }
            }

            foreach (int alg in new int[] { Algs.Des, Algs.TripleDes, Algs.Rc4, Algs.Xor })
            {
                string s = "Stream & Block 中文 " + new string('z', 300);
                byte[] enc = Symmetric.Encrypt(Codec.Utf8(s), "key-123", alg, 128, CipherMode.CBC);
                byte[] dec = Symmetric.Decrypt(enc, "key-123", alg, 128);
                Check(Algs.Name(alg) + " 往返", Codec.Utf8(dec) == s, "解密结果不一致");
            }

            // 错误口令不应返回原文
            byte[] wrong = Symmetric.Decrypt(Symmetric.Encrypt(Codec.Utf8("secret"), "right", Algs.Aes, 256, CipherMode.CBC), "wrong", Algs.Aes, 256);
            Check("错误口令不可解出原文", Codec.Utf8(wrong) != "secret", "居然解出了原文");
        }

        private static void TestClassic()
        {
            Console.WriteLine("[古典密码]");
            Eq("摩斯编码", "... --- ...", Classic.MorseEncode("SOS"));
            Eq("摩斯解码", "SOS", Classic.MorseDecode("... --- ..."));
            Eq("摩斯往返", "HELLO WORLD", Classic.MorseDecode(Classic.MorseEncode("hello world")));
            Eq("数字摩斯", "..... .---- ..--- ...--", Classic.MorseEncode("5123"));
            Eq("凯撒 +3", "Khoor Zruog", Classic.Caesar("Hello World", 3));
            Eq("凯撒 -3", "Hello World", Classic.Caesar("Khoor Zruog", -3));
            Eq("ROT13", "Uryyb Jbeyq", Classic.Rot13("Hello World"));
            Eq("Atbash", "Svool Dliow", Classic.Atbash("Hello World"));
            Eq("维吉尼亚加密", "Rijvs Uyvjn", Classic.Vigenere("Hello World", "KEY", false));
            Eq("维吉尼亚解密", "Hello World", Classic.Vigenere("Rijvs Uyvjn", "KEY", true));
        }

        private static void TestRsa()
        {
            Console.WriteLine("[RSA]");
            using (RSA rsa = RsaTool.Generate(2048))
            {
                Check("密钥长度 2048", RsaTool.KeyBits(rsa) == 2048, "实际 " + RsaTool.KeyBits(rsa));

                string privPem = RsaTool.ToPemPrivate(rsa);
                string pubPem = RsaTool.ToPemPublic(rsa);
                Check("私钥 PEM 头", privPem.StartsWith("-----BEGIN PRIVATE KEY-----"), privPem.Substring(0, 30));
                Check("公钥 PEM 头", pubPem.StartsWith("-----BEGIN PUBLIC KEY-----"), pubPem.Substring(0, 30));

                using (RSA reimported = RsaTool.FromPemPrivate(privPem))
                {
                    Check("私钥 PEM 往返", reimported.ToXmlString(true) == rsa.ToXmlString(true), "参数不一致");
                }
                using (RSA pub = RsaTool.FromPemPublic(pubPem))
                {
                    string text = "RSA 中文测试 payload";
                    byte[] enc = RsaTool.EncryptBytes(Codec.Utf8(text), pub);
                    byte[] dec = RsaTool.DecryptBytes(enc, rsa);
                    Eq("公钥加密/私钥解密", text, Codec.Utf8(dec));

                    string sig = RsaTool.SignBase64(text, rsa, "SHA256");
                    Check("签名验证通过", RsaTool.VerifyBase64(text, sig, pub, "SHA256"), "验签失败");
                    Check("篡改后验签失败", !RsaTool.VerifyBase64(text + "x", sig, pub, "SHA256"), "篡改仍通过");
                }
            }
        }

        private static void TestPasswordTools()
        {
            Console.WriteLine("[口令工具]");
            Check("内置库数量", PasswordTools.Count >= 200, "实际 " + PasswordTools.Count);
            Check("命中常见口令", PasswordTools.FindCommon("Password") != null, "未命中");
            Check("非弱口令", PasswordTools.FindCommon("X9#mQ2!vLp7@") == null, "误判为常见口令");

            StrengthResult weak = PasswordTools.Evaluate("123456");
            Check("弱口令评分低", weak.Score < 20 && weak.IsCommon, "score=" + weak.Score);
            StrengthResult strong = PasswordTools.Evaluate("X9#mQ2!vLp7@Zt4");
            Check("强口令评分高", strong.Score >= 70, "score=" + strong.Score);

            string alg;
            int tried;
            string hit = PasswordTools.LookupHash("e10adc3949ba59abbe56e057f20f883e", out alg, out tried);
            Eq("MD5 反查 123456", "123456", hit);
            Check("反查算法识别", alg == "MD5", "alg=" + alg);
            string hit2 = PasswordTools.LookupHash(Digests.HashHex("SHA256", Codec.Utf8("qwerty")), out alg, out tried);
            Eq("SHA256 反查 qwerty", "qwerty", hit2);
            string miss = PasswordTools.LookupHash(Digests.HashHex("MD5", Codec.Utf8("X9#mQ2!vLp7@")), out alg, out tried);
            Check("未知散列未命中", miss == null, "不应命中");

            string gen = PasswordTools.Generate(20, true, true, true, true, true);
            Check("随机口令长度", gen.Length == 20, "实际 " + gen.Length);
            Check("随机口令含数字", System.Text.RegularExpressions.Regex.IsMatch(gen, "[2-9]"), gen);
            Check("随机口令无易混淆字符", gen.IndexOfAny(new char[] { 'I', 'l', '1', 'O', '0' }) < 0, gen);
            string gen2 = PasswordTools.Generate(20, true, true, true, true, true);
            Check("两次生成不同", gen != gen2, "相同");
        }

        private static void TestFileCrypto()
        {
            Console.WriteLine("[文件加解密]");
            string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "selftest_tmp");
            Directory.CreateDirectory(dir);
            string src = Path.Combine(dir, "sample.bin");
            string enc = Path.Combine(dir, "sample.bin.enc");
            string dec = Path.Combine(dir, "sample.bin.dec");
            byte[] data = new byte[256 * 1024];
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider()) rng.GetBytes(data);
            File.WriteAllBytes(src, data);

            double progress = 0;
            FileCrypto.Encrypt(src, enc, "file-pass-测试", p => progress = p);
            Check("文件加密完成", File.Exists(enc) && new FileInfo(enc).Length > 36, "输出异常");
            Check("进度回调 100%", progress >= 0.999, "progress=" + progress);
            FileCrypto.Decrypt(enc, dec, "file-pass-测试", p => progress = p);
            byte[] back = File.ReadAllBytes(dec);
            Check("文件往返一致", back.Length == data.Length && Convert.ToBase64String(back) == Convert.ToBase64String(data), "内容不一致");

            bool rejected = false;
            try
            {
                File.WriteAllBytes(enc, Codec.Utf8("not a cipherbox file"));
                FileCrypto.Decrypt(enc, dec, "file-pass-测试", null);
            }
            catch (FormatException) { rejected = true; }
            Check("非法文件被拒绝", rejected, "未抛出格式错误");

            Directory.Delete(dir, true);
        }
    }
}
