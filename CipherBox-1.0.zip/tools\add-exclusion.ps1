# Adds a Windows Defender exclusion for the CipherBox folder (asks for UAC).
$ErrorActionPreference = "Stop"

$toolDir = Split-Path -Parent $PSScriptRoot
$me = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($me)

if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Requesting administrator rights..." -ForegroundColor Yellow
    $cliArgs = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", ('"{0}"' -f $PSCommandPath)
    )
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $cliArgs | Out-Null
    exit
}

try {
    Add-MpPreference -ExclusionPath $toolDir -ErrorAction Stop
    Write-Host ""
    Write-Host "Done. Windows Defender will ignore this folder from now on:" -ForegroundColor Green
    Write-Host "  $toolDir"
    Write-Host ""
    Write-Host "To undo later: Windows Security > Virus & threat protection >" -ForegroundColor DarkGray
    Write-Host "Manage settings > Exclusions > remove the folder." -ForegroundColor DarkGray
}
catch {
    Write-Host "Failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "You can add the exclusion manually in Windows Security." -ForegroundColor DarkGray
}

Write-Host ""
Read-Host "Press Enter to close"
